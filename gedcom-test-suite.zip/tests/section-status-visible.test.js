// v59: a grouped section's header colour is computed over exactly the rows
// DISPLAYED beneath it - never over rows hidden by "Hide people with no date of
// birth", "Hide people likely still alive", or an unticked summary-card category.
// (Before v59 the header looked at every in-scope row, so a hidden row could turn
// a header amber/red/dark red with nothing visible to explain it.)
const { loadApp, check, summary } = require('../harness');

// Frank (the root's father) is an exact match. Under him, siblings:
//  - "Undated Smith": only in File A, no birth date  -> a missing person
//  - "Ann Smith": in both, born 1990 (likely alive), but birth place differs
const gedA = `0 @R@ INDI
1 NAME Root /Smith/
1 BIRT
2 DATE 1960
1 FAMC @F1@
0 @F@ INDI
1 NAME Frank /Smith/
1 BIRT
2 DATE 1930
1 FAMS @F1@
1 FAMC @F2@
0 @S1@ INDI
1 NAME Undated /Smith/
1 FAMC @F2@
0 @S2@ INDI
1 NAME Ann /Smith/
1 BIRT
2 DATE 1990
2 PLAC Leeds
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @F@
1 CHIL @R@
0 @F2@ FAM
1 CHIL @F@
1 CHIL @S1@
1 CHIL @S2@
`;
const gedB = `0 @R@ INDI
1 NAME Root /Smith/
1 BIRT
2 DATE 1960
1 FAMC @F1@
0 @F@ INDI
1 NAME Frank /Smith/
1 BIRT
2 DATE 1930
1 FAMS @F1@
1 FAMC @F2@
0 @S2@ INDI
1 NAME Ann /Smith/
1 BIRT
2 DATE 1990
2 PLAC Paris
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @F@
1 CHIL @R@
0 @F2@ FAM
1 CHIL @F@
1 CHIL @S2@
`;

// Returns { 'Header Name': 'status-class' } for the grouped sections rendered.
function headerStatuses(overrides, categoryVisibility) {
  const app = loadApp(Object.assign({
    rootA: 'R', rootB: 'R', maxGen: '2', groupByAncestor: true, hideAllSubDetails: false,
    includeSiblings: true, generationLimit: 'all',
    categoryVisibility: Object.assign({ exact: true }, categoryVisibility || {})
  }, overrides));
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  const out = app._document._el('report').innerHTML;
  const res = {};
  const re = /section-head status-(\w+)">[\s\S]*?match-header-name">([^<(]+)/g;
  let m;
  while ((m = re.exec(out))) res[m[2].trim()] = m[1];
  return res;
}

// 1. The undated missing sibling is hidden by "hide no birth date", and Ann (born
//    1990, likely alive, place differs) is hidden by "hide likely alive" -> Frank's
//    header is the clean deep green.
check(headerStatuses({ hideNoBirthDate: true })['Frank Smith'], 'exact',
  'hidden undated-missing + hidden likely-alive diff do not colour the header');

// 2. With the no-birth-date filter off, the missing sibling is listed -> dark red.
check(headerStatuses({ hideNoBirthDate: false })['Frank Smith'], 'missing',
  'once the missing sibling is visible it does colour the header');

// 3. Same, but the Missing summary-card category is unticked -> hidden again.
check(headerStatuses({ hideNoBirthDate: false }, { missing: false })['Frank Smith'], 'exact',
  'a category hidden via its summary card no longer colours the header');

// 4. With "hide likely alive" off, Ann's differing birth place is listed and does colour it.
const ann = headerStatuses({ hideNoBirthDate: true, ignoreLikelyAlive: false })['Frank Smith'];
check(ann === 'amber' || ann === 'red', true,
  'once the likely-alive person with a difference is visible it colours the header (got ' + ann + ')');

process.exit(summary('section-status-visible'));
