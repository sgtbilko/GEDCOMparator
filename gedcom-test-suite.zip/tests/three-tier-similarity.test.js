// v42: the unified 3-tier model. For Name, Date and Location, the slider sets
// t_similar and a fixed per-field multiplier k derives t_substantial:
//   name k=3, date k=10, location k=1.5.
// distance <= t_similar -> similar; <= t_substantial -> different (amber);
// beyond -> substantially different (red). Adjusting ANY slider can therefore
// move a match into any of the three categories.
const { loadApp, check, summary } = require('../harness');

const app = loadApp();
const {
  classifyName, nameDistance, dateGapDays, birthDateSubstantiallyDifferent,
  birthPlaceSubstantiallyDifferent, birthSubstantiallyDifferentRaw, datesMatch
} = app;

function name(given, surname) { return { given, surname, full: `${given} ${surname}`.trim() }; }

// SUBSTANTIAL_K is a top-level const, so it is read through getVar.
check(app.getVar('SUBSTANTIAL_K'), { name: 3, date: 10, location: 1.5 },
  'k multipliers: name 3, date 10, location 1.5');

// ---------- NAME ----------
// Catherine/Kathryn: 4 edits over 9 letters = ~44%
const cat = name('Catherine', 'Smith'), kat = name('Kathryn', 'Smith');
check(Math.round(nameDistance(cat, kat) * 100), 44, 'name: Catherine/Kathryn distance is ~44% (edit distance / longer length)');
check(classifyName(cat, kat, 0.45), 'similar', 'name: slider 45% -> similar (44% is within it)');
check(classifyName(cat, kat, 0.15), 'different', 'name: slider 15% -> different (44% is above 15% but within the 45% red bar)');
check(classifyName(cat, kat, 0.10), 'substantial', 'name: slider 10% -> substantial (44% is beyond the 30% red bar)');
check(classifyName(cat, kat, 0.14), 'substantial', 'name: slider 14% -> substantial (red bar 42% is still below 44%)');
check(classifyName(cat, kat, 0.15), 'different', 'name: slider 15% -> different (red bar 45% just clears 44%): one 1% step flips red to amber');
check(classifyName(name('John', 'Smith'), name('John Michael', 'Smith'), 0.15), 'similar',
  'name: an extra middle name never adds distance, so it is similar (text differs, within tolerance)');
check(classifyName(name('John', 'Smith'), name('john', 'SMITH'), 0), 'exact', 'name: identical ignoring case is exact at any tolerance');
check(classifyName(name('', ''), name('John', 'Smith'), 0.15), 'different',
  'name: nothing comparable (one side has no name) is different (amber), never similar or red');
// Worst of surname/first-given decides
check(classifyName(name('John', 'Smith'), name('John', 'Jones'), 0.15), 'substantial',
  'name: a different surname alone drives the tier (Smith/Jones 80% > 45%)');

// ---------- DATE (birth only), k = 10 ----------
check(dateGapDays('Jun 1900', 'Sep 1900') > 90 && dateGapDays('Jun 1900', 'Sep 1900') < 93, true, 'date: gap is measured in days between midpoints');
check(dateGapDays('1900', ''), null, 'date: a blank side has no gap (missing data)');
check(dateGapDays('Bef 1900', 'Bef 1850') > 365 * 49, true, 'date: qualifiers are ignored for distance, so Bef 1900 vs Bef 1850 is ~50 years');
// year-only 1900 vs 1902 = 730 days; vs 1903 = 1096 days
check(datesMatch('1900', '1902', 91), false, 'date: 2 years apart is not "similar" at the 91-day default');
check(birthDateSubstantiallyDifferent('1900', '1902', 91), false, 'date: ...and 730 days is within the 910-day red bar -> different (amber), not red');
check(birthDateSubstantiallyDifferent('1900', '1903', 91), true, 'date: 1096 days is beyond the 910-day red bar -> red');
check(datesMatch('1900', '1902', 730), true, 'date: widen the slider to 730 days and 2 years apart becomes similar');
check(birthDateSubstantiallyDifferent('1900', '1903', 120), false, 'date: widen the slider to 120 (red bar 1200 days) and 3 years is no longer red');
check(birthDateSubstantiallyDifferent('1900', '1903', 7), true, 'date: narrow the slider to 7 days (red bar 70 days) and it is red again');
// Hard override: full dates must match to the day for similar, but the RED bar still scales with the slider.
check(datesMatch('12 Jan 1900', '13 Jan 1900', 365), false, 'date override: full dates one day apart are never "similar", whatever the slider');
check(birthDateSubstantiallyDifferent('12 Jan 1900', '13 Jan 1900', 91), false, 'date override: a one-day slip in a full date is amber, not red');
check(birthDateSubstantiallyDifferent('12 Jan 1900', '12 Jan 1903', 91), true, 'date: a 3-year slip in a full date is red');
check(birthDateSubstantiallyDifferent('', '1903', 91), false, 'date: blank on one side is never red');

// ---------- LOCATION (birth only), k = 1.5; arg is the MIN similarity that counts as a match ----------
// Springfield, Illinois vs Tokyo, Japan is very dissimilar; Boston vs Baston moderately similar.
const far = ['Springfield, Illinois', 'Tokyo, Japan'];
check(birthPlaceSubstantiallyDifferent(far[0], far[1], 0.5), true, 'location: unrelated places at the 50% default -> red');
check(birthPlaceSubstantiallyDifferent(far[0], far[1], 0.0), false, 'location: slider 100% (anything matches) -> nothing can be red (cutoff capped at distance 1)');
check(birthPlaceSubstantiallyDifferent('Springfield, Illinois', 'Springfield, IL', 0.5), false, 'location: related variants at the default -> not red');
// Override: subset/superset is never red, even at the strictest setting
check(birthPlaceSubstantiallyDifferent('Torgau, Germany', 'Germany', 1.0), false, 'location override: subset/superset is never red, even at 0% tolerance');
check(birthPlaceSubstantiallyDifferent('', 'Tokyo', 0.5), false, 'location: blank on one side is never red');
// The red bar moves with the slider: pick a pair between the two bars at the default
{
  const a = 'Springfield, Illinois', b = 'Springfield, Ohio';
  const sim = app.placeSimilarity(a, b);
  const dist = 1 - sim;
  // choose tolerance so t_sim < dist <= t_sub  (sim < thr, dist <= (1-thr)*1.5)
  const thr = 0.9;                 // tolerance 10%: t_sim 0.1, t_sub 0.15
  check(dist > 0.1, true, 'location: sanity - the pair is more than 10% different');
  check(birthPlaceSubstantiallyDifferent(a, b, thr), dist > 0.15, 'location: red exactly when the pair is beyond 1.5x the tolerance');
  check(birthPlaceSubstantiallyDifferent(a, b, 0.4), false, 'location: a looser 60% tolerance leaves the same pair un-flagged');
}

// ---------- ONLY name + birth can turn a row red (death / marriage never do) ----------
const gedA = `0 @I1@ INDI
1 NAME John /Smith/
1 FAMS @F1@
1 BIRT
2 DATE 1900
2 PLAC Boston
1 DEAT
2 DATE 1950
2 PLAC Boston
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
const gedB = `0 @P1@ INDI
1 NAME John /Smith/
1 FAMS @G1@
1 BIRT
2 DATE 1900
2 PLAC Boston
1 DEAT
2 DATE 1990
2 PLAC Tokyo, Japan
0 @P2@ INDI
1 NAME Jane /Doe/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P1@
1 WIFE @P2@
`;
{
  const a2 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { similar: true } });
  a2.loadGedcomFiles(gedA, gedB);
  a2.runCompare();
  const root = a2.getVar('lastSections').find(s => s.label === 'Root');
  check(a2.rowSubstantiallyDifferent(root.ancestorHeader, 0.15, 91, 0.5), false,
    'scope: a 40-year death-date gap and an unrelated death place do NOT make the row red (birth is identical)');
  check(a2.rowHasEffectiveDiff(root.ancestorHeader, true, 0.5, 91, 0.15), true,
    'scope: ...they only make it an ordinary (amber) difference');
}

// ---------- End to end: one slider moves the same pair across all three categories ----------
{
  const gA = `0 @I1@ INDI
1 NAME John /Smith/
1 FAMS @F1@
1 BIRT
2 DATE 1900
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
  const gB = gA.replace('DATE 1900', 'DATE 1902').replace(/@I/g, '@P').replace(/@F1@/g, '@G1@');
  const a3 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } });
  a3.loadGedcomFiles(gA, gB);
  a3.runCompare();
  const root = a3.getVar('lastSections').find(s => s.label === 'Root');
  const row = root.ancestorHeader;
  function tierAt(days) {
    if (a3.rowSubstantiallyDifferent(row, 0.15, days, 0.5)) return 'red';
    if (a3.rowHasEffectiveDiff(row, true, 0.5, days, 0.15)) return 'amber';
    return a3.matchExactness(row, true, 0.5, days, 0.15) === 'exact' ? 'exact' : 'similar';
  }
  check(tierAt(7), 'red', 'end to end: 1900 vs 1902, date tolerance 7 days (red bar 70) -> red');
  check(tierAt(91), 'amber', 'end to end: same pair at the 91-day default -> amber');
  check(tierAt(730), 'similar', 'end to end: same pair at 730 days -> similar');
  a3._document._el('dateTolerance').value = '7';
  a3.renderReport();
  check(a3._document._el('report').innerHTML.includes('badge substantial-diff'), true, 'end to end (rendered): slider at 7 days shows the red badge');
  a3._document._el('dateTolerance').value = '91';
  a3.renderReport();
  check(a3._document._el('report').innerHTML.includes('badge substantial-diff'), false, 'end to end (rendered): back at 91 days the red badge is gone with no re-compare');
  check(a3._document._el('dateSubstVal').textContent, '910 days', 'end to end (rendered): the live red-cutoff read-out shows 91 x 10 = 910 days');
}

// ---------- Live read-outs for the other two sliders ----------
{
  const a4 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { similar: true } });
  a4.loadGedcomFiles(gedA, gedB);
  a4.runCompare();
  check(a4._document._el('nameSubstVal').textContent, '45%', 'read-out: name red cutoff at the 15% default is 45%');
  check(a4._document._el('locationSubstVal').textContent, '75%', 'read-out: location red cutoff at the 50% default is 75% different');
  a4._document._el('nameTolerance').value = '30';
  a4.renderReport();
  check(a4._document._el('nameSubstVal').textContent, '90%', 'read-out: name at the slider maximum (30%) puts the red bar at 90%');
}

// ---------- Location slider direction (corrected in v42): higher = more lenient ----------
{
  const gA = `0 @I1@ INDI
1 NAME John /Smith/
1 FAMS @F1@
1 BIRT
2 DATE 1900
2 PLAC Springfield, Illinois
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
  const gB = gA.replace('Springfield, Illinois', 'Springfield, IL').replace(/@I/g, '@P').replace(/@F1@/g, '@G1@');
  const a5 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', locationTolerance: '0', categoryVisibility: { similar: true } });
  a5.loadGedcomFiles(gA, gB);
  a5.runCompare();
  check(a5._document._el('report').innerHTML.includes('similar in both'), false, 'location direction: tolerance 0% -> exact only, the variant place is a plain diff');
  a5._document._el('locationTolerance').value = '50';
  a5.renderReport();
  check(a5._document._el('report').innerHTML.includes('similar in both'), true, 'location direction: tolerance 50% -> the variant place is treated as similar');
  a5._document._el('locationTolerance').value = '100';
  a5.renderReport();
  check(a5._document._el('report').innerHTML.includes('similar in both'), true, 'location direction: tolerance 100% -> still similar (raising the slider never makes matching stricter)');
}

process.exit(summary('three-tier-similarity'));
