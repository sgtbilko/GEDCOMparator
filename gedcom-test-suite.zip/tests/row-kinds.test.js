// v63: every row carries structured { kind, depth }, and the kind-based cores
// agree with the string-based wrappers that older callers/tests still use.
const { loadApp, check, summary } = require('../harness');
const { buildTree, toGedcom, MUTATION } = require('../gen-fixture');

const tree = buildTree(4, 7);
const eq = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const kinds = new Set();
let totalRows = 0, totalMissing = 0;

function audit(label, app) {
  const { roleToKind, relationshipInfo, relationshipInfoForKind, distanceFromRoot, distanceForKind } = app;
  let rows = 0, kindOk = 0, depthOk = 0, relOk = 0, coreOk = 0, distOk = 0, unknown = 0;
  for (const section of app.getVar('lastSections')) {
    for (const row of section.rows) {
      rows++; kinds.add(row.kind); if (row.status === 'missA' || row.status === 'missB') totalMissing++;
      const k = roleToKind(row.role);
      if (k.kind === 'unknown') unknown++;
      if (row.kind === k.kind) kindOk++;
      if (row.depth === k.depth) depthOk++;
      // relationshipInfo is sex-dependent; the row's sex isn't stored, so try all three.
      if (['M', 'F', ''].every(s => eq(relationshipInfo(row.role, section.code, row.depth, s), relationshipInfoForKind(row.kind, row.role, section.code, row.depth, s)))) coreOk++;
      if (['M', 'F', ''].some(s => { const a = relationshipInfo(row.role, section.code, row.depth, s); return a.relationshipTerm === row.relationshipTerm && a.pathDescription === row.pathDescription; })) relOk++;
      if (row.distance === distanceFromRoot(row.role, section.code) && row.distance === distanceForKind(row.kind, row.depth, section.code)) distOk++;
    }
  }
  totalRows += rows;
  check(rows > 0, true, `${label}: has rows (${rows})`);
  check(unknown, 0, `${label}: no row has an unrecognised role`);
  check(kindOk, rows, `${label}: row.kind equals roleToKind(row.role).kind for every row`);
  check(depthOk, rows, `${label}: row.depth equals roleToKind(row.role).depth for every row`);
  check(relOk, rows, `${label}: relationshipInfo(role, code, depth, sex) reproduces every row's stored term/path`);
  check(coreOk, rows, `${label}: kind-based core and string wrapper agree (all sexes)`);
  check(distOk, rows, `${label}: row.distance equals distanceFromRoot(role, code) and distanceForKind`);
}

// 1) the synthetic fixture pair, everything enabled
const big = loadApp({ rootA: 'I1', rootB: 'I1', maxGen: '4', includeSiblings: true, includeSibSpouses: true,
  includeAncestorSpouses: true, descendantGen: '3', generationLimit: 'all' });
big.loadGedcomFiles(toGedcom(tree, null, 1), toGedcom(tree, MUTATION, 2));
big.runCompare();
audit('fixture', big);

// 2) a tiny hand-built pair that has a sibling's spouse (the fixture has none):
// Root's sibling Sis is married to Hubby in A and B (matched) and to Extra in A only (missing from B).
const ged = extra => `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
0 @I3@ INDI
1 NAME Sis /Person/
1 SEX F
1 FAMC @F1@
1 FAMS @F2@${extra ? '\n1 FAMS @F3@' : ''}
0 @I4@ INDI
1 NAME Hubby /Other/
1 SEX M
1 FAMS @F2@${extra ? '\n0 @I5@ INDI\n1 NAME Extra /Other/\n1 SEX M\n1 FAMS @F3@' : ''}
0 @F1@ FAM
1 HUSB @I2@
1 CHIL @I1@
1 CHIL @I3@
0 @F2@ FAM
1 HUSB @I4@
1 WIFE @I3@
1 MARR
2 DATE 1 Jan 1900${extra ? '\n0 @F3@ FAM\n1 HUSB @I5@\n1 WIFE @I3@' : ''}
`;
const small = loadApp({ rootA: 'I1', rootB: 'I1', maxGen: '2', includeSiblings: true, includeSibSpouses: true,
  includeAncestorSpouses: true, descendantGen: '0', generationLimit: 'all' });
small.loadGedcomFiles(ged(true), ged(false));
small.runCompare();
audit('sibling-spouse fixture', small);

check(totalRows > 50, true, `enough rows audited overall (${totalRows})`);
check(totalMissing > 0, true, 'audit includes one-sided (missing) rows');
for (const kd of ['ancestor', 'sibling', 'spouse', 'siblingSpouse', 'descendant', 'descendantSpouse'])
  check(kinds.has(kd), true, `kind '${kd}' is exercised`);

const { roleToKind, distanceFromRoot } = big;
// adapter edge cases
check(eq(roleToKind('Ancestor'), { kind: 'ancestor', depth: null }), true, 'Ancestor');
check(eq(roleToKind('Child'), { kind: 'descendant', depth: 1 }), true, 'Child');
check(eq(roleToKind('Great-great-grandchild'), { kind: 'descendant', depth: 4 }), true, '2x great-grandchild depth 4');
check(eq(roleToKind("Sibling's spouse"), { kind: 'siblingSpouse', depth: null }), true, "Sibling's spouse is NOT a descendant spouse");
check(eq(roleToKind("Grandchild's spouse"), { kind: 'descendantSpouse', depth: 2 }), true, "Grandchild's spouse");
check(eq(roleToKind('Banana'), { kind: 'unknown', depth: null }), true, 'unknown role');
check(distanceFromRoot('Banana', 'F'), null, 'unknown role has no distance');

process.exit(summary('row-kinds'));
