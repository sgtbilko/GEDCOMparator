// v43/v44: qualifier and month-name wording variants (ABT/Abt./abt/About/circa, Bef/Before,
// Aft/After) on otherwise identical dates are an EXACT match, not "similar".
const { loadApp, check, summary } = require('../harness');
const app = loadApp();
const { dateTextEquivalent, canonicalDateText, matchExactness, datesMatch } = app;

const variants = [
  ['ABT 1900', 'Abt. 1900'], ['ABT 1900', 'abt 1900'], ['Abt 1900', 'About 1900'],
  ['abt 1900', 'ABOUT 1900'], ['Abt. 1900', 'circa 1900'],
  ['Bef 1900', 'Before 1900'], ['BEF. 1900', 'before 1900'],
  ['Aft 1900', 'After 1900'], ['AFT. 1900', 'after 1900'],
  ['Abt 12 Nov 1900', 'About 12 Nov 1900'], ['Abt  1900', 'abt 1900'],
  ['12 Nov 1900', '12 November 1900'], ['12 NOV. 1900', '12 november 1900'], ['3 Sept. 1888', '3 Sep 1888'],
  ['Nov 1900', 'November 1900'], ['Abt Nov 1900', 'About November. 1900'], ['3 Sept 1888', '3 September 1888']
];
for (const [a, b] of variants) {
  check(dateTextEquivalent(a, b), true, `text equivalent: "${a}" ~ "${b}"`);
  const row = { status: 'both', fieldDiffs: [{ label: 'Birth date', a, b, same: true, type: 'date', similarity: 1 }] };
  check(matchExactness(row, true, 0.5, 91, 0.15), 'exact', `exactness: "${a}" vs "${b}" is exact, not similar`);
}

// Things that must still be only "similar" / not equivalent
const notEquivalent = [
  ['Abt 1900', 'Bef 1900'], ['Bef 1900', 'Aft 1900'], ['Abt 1900', '1900'],
  ['Abt 1900', 'Abt 1901'], ['Cal 1900', 'Abt 1900'], ['12 Nov 1900', '13 November 1900'], ['12 Nov 1900', '12 Dec 1900'], ['Nov 1900', 'Nov 1901']
];
for (const [a, b] of notEquivalent) {
  check(dateTextEquivalent(a, b), false, `not equivalent: "${a}" vs "${b}"`);
}
{
  const row = { status: 'both', fieldDiffs: [{ label: 'Birth date', a: '12 Nov 1900', b: '12 November 1900', same: true, type: 'date', similarity: 1 }] };
  check(matchExactness(row, true, 0.5, 91, 0.15), 'exact', 'exactness: month-name wording (Nov/November) is exact (v44)');
  const row2 = { status: 'both', fieldDiffs: [{ label: 'Birth date', a: 'Abt 1900', b: 'Abt 1902', same: true, type: 'date', similarity: 1 }] };
  check(matchExactness(row2, true, 0.5, 730, 0.15), 'similar', 'exactness: two different approximate dates matched by tolerance are still similar');
}
check(canonicalDateText('  About   1900 '), 'abt 1900', 'canonical form collapses spacing and qualifier spelling');
check(canonicalDateText('12 NOVEMBER. 1900'), '12 nov 1900', 'canonical form folds month spelling and period');
check(datesMatch('Abt. 1900', 'About 1900'), true, 'tolerance logic unchanged: still a date match');

// End to end: rendered report shows an exact match, no "equivalent" note
const gA = `0 @I1@ INDI
1 NAME John /Smith/
1 BIRT
2 DATE Abt. 1900
`;
const gB = `0 @P1@ INDI
1 NAME John /Smith/
1 BIRT
2 DATE ABOUT 1900
`;
const a2 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true }, ignoreLikelyAlive: false });
a2.loadGedcomFiles(gA, gB);
a2.runCompare();
const html = a2._document._el('report').innerHTML;
check(html.includes('dates recognized as equivalent'), false, 'end to end: no "dates recognized as equivalent" note for qualifier variants');
check(html.includes('badge exact'), true, 'end to end: the row carries the deep-green Exact match badge');
process.exit(summary('qualifier-exactness'));
