// v52: "Generations back" and "Descendant generations" are dropdowns offering
// 0-9 plus "All" (no limit); "All" must really walk to the end of the data, and
// neither walk may loop on cyclic data.
const fs = require('fs');
const path = require('path');
const { loadApp, check, summary } = require('../harness');

const html = fs.readFileSync(path.join(__dirname, '..', 'GEDCOMparator.html'), 'utf8');
function optionsOf(id) {
  const m = html.match(new RegExp(`<select id="${id}"[^>]*>([\\s\\S]*?)</select>`));
  return m ? [...m[1].matchAll(/<option value="([^"]*)"( selected)?>([^<]*)<\/option>/g)].map(x => ({ value: x[1], selected: !!x[2], text: x[3] })) : null;
}
for (const [id, def] of [['maxGen', '6'], ['descendantGen', '0']]) {
  const o = optionsOf(id);
  check(o !== null, true, `${id} is a dropdown`);
  check(o.map(x => x.value), ['0','1','2','3','4','5','6','7','8','9','all'], `${id} offers 0-9 then All, nothing above 9`);
  check(o[o.length - 1].text, 'All', `${id}: the final option reads "All"`);
  check(o.filter(x => x.selected).map(x => x.value), [def], `${id} defaults to ${def}`);
}

const app0 = loadApp();
check([app0.parseGenerationSetting('all', 6), app0.parseGenerationSetting('ALL', 6), app0.parseGenerationSetting('3', 6),
       app0.parseGenerationSetting('0', 6), app0.parseGenerationSetting('', 6), app0.parseGenerationSetting('junk', 0)],
      [Infinity, Infinity, 3, 0, 6, 0], 'parseGenerationSetting: All -> Infinity, digits parse (0 is valid), junk -> default');

// ---- ancestors: an 18-generation paternal line ----
function ancestry(p, n) {
  let out = `0 @${p}0@ INDI\n1 NAME G0 /Person/\n1 FAMC @${p}F1@\n`;
  for (let i = 1; i <= n; i++) {
    out += `0 @${p}${i}@ INDI\n1 NAME G${i} /Person/\n` + (i < n ? `1 FAMC @${p}F${i + 1}@\n` : '') + `1 FAMS @${p}F${i}@\n`;
    out += `0 @${p}F${i}@ FAM\n1 HUSB @${p}${i}@\n1 CHIL @${p}${i - 1}@\n`;
  }
  return out;
}
const sectionCodes = app => app.getVar('lastSections').map(s => s.code);
{
  const app = loadApp({ rootA: 'I0', rootB: 'P0', maxGen: 'all', generationLimit: 'all', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(ancestry('I', 18), ancestry('P', 18));
  app.runCompare();
  check(Math.max(...sectionCodes(app).map(c => c.length)), 18, 'Generations back = All reaches all 18 generations (old max was 12)');
}
for (const [val, want] of [['0', 0], ['3', 3], ['9', 9]]) {
  const app = loadApp({ rootA: 'I0', rootB: 'P0', maxGen: val, generationLimit: 'all', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(ancestry('I', 18), ancestry('P', 18));
  app.runCompare();
  check(Math.max(...sectionCodes(app).map(c => c.length)), want, `Generations back = ${val} stops at exactly ${want}` + (want === 0 ? ' (root alone; used to become 6)' : ''));
}

// ---- descendants: a 15-deep chain ----
function chain(p, n) {
  let out = `0 @${p}R@ INDI\n1 NAME Root /Person/\n1 FAMS @${p}F0@\n0 @${p}F0@ FAM\n1 HUSB @${p}R@\n1 CHIL @${p}K1@\n`;
  for (let i = 1; i <= n; i++) {
    out += `0 @${p}K${i}@ INDI\n1 NAME K${i} /Person/\n1 FAMC @${p}F${i - 1}@\n` + (i < n ? `1 FAMS @${p}F${i}@\n` : '');
    if (i < n) out += `0 @${p}F${i}@ FAM\n1 HUSB @${p}K${i}@\n1 CHIL @${p}K${i + 1}@\n`;
  }
  return out;
}
const kids = app => app.getVar('lastSections').find(s => s.label === 'Root').rows.filter(r => /^K\d+ /.test(r.name)).length;
for (const [val, want] of [['all', 15], ['9', 9], ['1', 1], ['0', 0]]) {
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '0', descendantGen: val, categoryVisibility: { exact: true } });
  app.loadGedcomFiles(chain('I', 15), chain('P', 15));
  app.runCompare();
  check(kids(app), want, `Descendant generations = ${val} lists ${want} descendants of a 15-deep chain`);
}

// ---- cycles with "All" must terminate ----
{
  // Root is (bad data) his own father's father: R -> FA -> R.
  const cyc = p => `0 @${p}R@ INDI\n1 NAME Root /Person/\n1 FAMC @${p}F1@\n1 FAMS @${p}F2@\n0 @${p}FA@ INDI\n1 NAME Father /Person/\n1 FAMC @${p}F2@\n1 FAMS @${p}F1@\n0 @${p}F1@ FAM\n1 HUSB @${p}FA@\n1 CHIL @${p}R@\n0 @${p}F2@ FAM\n1 HUSB @${p}R@\n1 CHIL @${p}FA@\n`;
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: 'all', descendantGen: 'all', generationLimit: 'all', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(cyc('I'), cyc('P'));
  app.runCompare();   // would overflow the stack without the guards
  check(sectionCodes(app), ['', 'F'], 'a person who is their own ancestor: All/All terminates, listing Root and Father once each as ancestors');
}
{
  // Pedigree collapse still works: same grandfather via both parents.
  const pc = p => `0 @${p}R@ INDI\n1 NAME Root /Person/\n1 FAMC @${p}F1@\n0 @${p}FA@ INDI\n1 NAME Dad /Person/\n1 FAMC @${p}G1@\n1 FAMS @${p}F1@\n0 @${p}MU@ INDI\n1 NAME Mum /Person/\n1 FAMC @${p}G1@\n1 FAMS @${p}F1@\n0 @${p}GR@ INDI\n1 NAME Grandad /Person/\n1 FAMS @${p}G1@\n0 @${p}F1@ FAM\n1 HUSB @${p}FA@\n1 WIFE @${p}MU@\n1 CHIL @${p}R@\n0 @${p}G1@ FAM\n1 HUSB @${p}GR@\n1 CHIL @${p}FA@\n1 CHIL @${p}MU@\n`;
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: 'all', generationLimit: 'all', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(pc('I'), pc('P'));
  app.runCompare();
  check(sectionCodes(app).includes('FF') && sectionCodes(app).includes('MF'), true,
    'pedigree collapse (same grandfather via father and mother) still yields a section under each route');
}

process.exit(summary('generation-options'));
