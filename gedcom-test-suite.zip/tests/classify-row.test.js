// classifyRow() must reproduce the per-row category rules exactly (missing;
// else substantial; else 'maybe' status or any effective diff -> diffs; else
// exact/similar from matchExactness), the summary cards must equal the tally
// of those categories, and computeSectionStatus must give the same colour with
// or without its optional classOf argument.
const { loadApp, check, summary } = require('../harness');
const { buildTree, toGedcom, MUTATION } = require('../gen-fixture');

const tree = buildTree(4, 7);
const gedA = toGedcom(tree, null, 1), gedB = toGedcom(tree, MUTATION, 2);
const app = loadApp({ rootA: 'I1', rootB: 'I1', maxGen: 'all', includeSiblings: true, includeSibSpouses: true,
  includeAncestorSpouses: true, descendantGen: '2', generationLimit: 'all', groupByAncestor: true, hideAllSubDetails: false,
  ignoreLikelyAlive: false,
  categoryVisibility: { exact: true, similar: true, diffs: true, substantial: true, missing: true } });
app.loadGedcomFiles(gedA, gedB);
app.runCompare();

const tol = { ignoreSimilarLocations: true, locationThreshold: 0.5, dateToleranceDays: 91, nameTolerance: 0.15 };
// the live default sliders (50% location tolerance, 91 days, 15% names)
const rows = app.getVar('lastSections').flatMap(s => s.rows);

function independent(row) {
  if (row.status === 'missA' || row.status === 'missB') return 'missing';
  if (app.rowSubstantiallyDifferent(row, tol.nameTolerance, tol.dateToleranceDays, tol.locationThreshold)) return 'substantial';
  const diff = app.rowHasEffectiveDiff(row, tol.ignoreSimilarLocations, tol.locationThreshold, tol.dateToleranceDays, tol.nameTolerance);
  if (row.status === 'maybe' || diff) return 'diffs';
  return app.matchExactness(row, tol.ignoreSimilarLocations, tol.locationThreshold, tol.dateToleranceDays, tol.nameTolerance) === 'exact' ? 'exact' : 'similar';
}

const seen = {};
let mismatches = 0;
for (const row of rows) {
  const c = app.classifyRow(row, tol);
  const want = independent(row);
  seen[want] = (seen[want] || 0) + 1;
  if (c.category !== want) mismatches++;
}
check(mismatches, 0, 'classifyRow category matches the independent derivation for every row (' + rows.length + ' rows)');
check(Object.keys(seen).length >= 4, true, 'fixture exercises at least four categories: ' + JSON.stringify(seen));

// summary-card numbers equal the category tally (all rows are in scope here)
const html = app._document._el('report').innerHTML;
const nums = [...html.matchAll(/<div class="card (\w+)"><div class="num">(\d+)<\/div>/g)].reduce((o, m) => (o[m[1]] = +m[2], o), {});
const tally = { exact: 0, similar: 0, diffs: 0, substantial: 0, missing: 0 };
for (const row of rows) tally[app.classifyRow(row, tol).category]++;
check(nums, tally, 'five summary-card numbers equal the classifyRow tally');

// header colour with and without the optional classOf argument
let statusMismatch = 0, sections = 0;
const STATUS = app.getVar('STATUS_OF_CATEGORY');
for (const s of app.getVar('lastSections')) {
  sections++;
  const args = [{ rows: s.rows }, false, 80, false, true, 0.5, 91, 0.15];
  const without = app.computeSectionStatus(...args);
  const withIt = app.computeSectionStatus(...args, row => app.classifyRow(row, tol));
  if (without !== withIt) statusMismatch++;
}
check(statusMismatch, 0, 'computeSectionStatus identical with/without classOf over ' + sections + ' sections');
check(STATUS.substantial === 'red' && STATUS.diffs === 'amber' && STATUS.missing === 'missing', true, 'STATUS_OF_CATEGORY maps categories to header colours');

process.exit(summary('classify-row'));
