// "Anonymous" as a trigger for the likely-still-alive check (v46).
const { loadApp, check, summary } = require('../harness');
const app = loadApp();
const { isLikelyAlive, isAnonymousName } = app;

check(isAnonymousName('Anonymous'), true, 'plain Anonymous');
check(isAnonymousName('ANONYMOUS Smith'), true, 'case-insensitive, with surname');
check(isAnonymousName('Mary Anonymous'), true, 'as surname');
check(isAnonymousName('Anonymousa Jones'), false, 'whole word only');
check(isAnonymousName(''), false, 'blank');

check(isLikelyAlive({ name: 'Anonymous', birthDate: '', deathDate: '' }, 80), true, 'Anonymous, no dates -> alive');
check(isLikelyAlive({ name: 'Anonymous', birthDate: '1700', deathDate: '' }, 80), true, 'Anonymous, ancient birth, no death -> alive');
check(isLikelyAlive({ name: 'Anonymous', birthDate: '', deathDate: '1850' }, 80), false, 'Anonymous with death date -> not alive');
check(isLikelyAlive({ name: 'John Smith', birthDate: '', deathDate: '' }, 80), false, 'normal name, no birth -> not alive');
check(isLikelyAlive({ name: 'John Smith', birthDate: '1700', deathDate: '' }, 80), false, 'normal old birth -> not alive');
check(isLikelyAlive({ name: 'John Smith', birthDate: '2000', deathDate: '' }, 80), true, 'normal recent birth -> alive (unchanged)');
check(isLikelyAlive({ name: 'John Smith', nameA: { full: 'John Smith' }, nameB: { full: 'Anonymous' }, birthDate: '', deathDate: '' }, 80), true, 'matched pair: either side Anonymous');
check(isLikelyAlive({ name: 'John Smith', nameA: { full: 'John Smith' }, nameB: { full: 'Anonymous' }, birthDate: '', deathDate: '1900' }, 80), false, 'matched pair Anonymous but death recorded');

// End-to-end: an Anonymous person missing from B is hidden by ignoreLikelyAlive.
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
0 @I3@ INDI
1 NAME Anonymous /Person/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I3@
1 CHIL @I1@
`;
const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMC @G1@
0 @P2@ INDI
1 NAME Dad /Person/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P2@
1 CHIL @P1@
`;
for (const hide of [true, false]) {
  const a = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', ignoreLikelyAlive: hide, categoryVisibility: { exact: true } });
  a.loadGedcomFiles(gedA, gedB);
  a.runCompare();
  const rendered = a._document.getElementById('report').innerHTML;
  check(rendered.includes('Anonymous'), !hide, `end-to-end: Anonymous row ${hide ? 'hidden' : 'shown'}`);
}
process.exit(summary('anonymous-alive'));
