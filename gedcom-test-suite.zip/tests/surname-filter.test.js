// v58: "Only show people with surname" display filter.
const { loadApp, check, summary } = require('../harness');

// Root Smith <- Dad Smith, Mum Jones.  Dad's siblings (Uncle Smythe only in A,
// Aunt Smith in both). Spelling variant: A "Catherine Jones" vs B "Catherine Johns".
const person = (id, name, extra = '') => `0 @${id}@ INDI\n1 NAME ${name}\n${extra}`;
function ged(p, f, { uncle }) {
  return [
    person(`${p}1`, 'Root /Smith/', `1 FAMC @${f}1@\n`),
    person(`${p}2`, 'Dad /Smith/', `1 FAMS @${f}1@\n1 FAMC @${f}2@\n`),
    person(`${p}3`, p === 'I' ? 'Catherine /Jones/' : 'Catherine /Johns/', `1 FAMS @${f}1@\n`),
    person(`${p}4`, 'Aunt /Smith/', `1 FAMC @${f}2@\n`),
    uncle ? person(`${p}5`, 'Uncle /Smythe/', `1 FAMC @${f}2@\n`) : '',
    `0 @${f}1@ FAM\n1 HUSB @${p}2@\n1 WIFE @${p}3@\n1 CHIL @${p}1@\n`,
    `0 @${f}2@ FAM\n1 CHIL @${p}2@\n1 CHIL @${p}4@\n${uncle ? `1 CHIL @${p}5@\n` : ''}`
  ].join('');
}
const gedA = ged('I', 'F', { uncle: true });
const gedB = ged('P', 'G', { uncle: false });
const NAMES = ['Root Smith', 'Dad Smith', 'Catherine', 'Aunt Smith', 'Uncle Smythe'];

function run(over) {
  const a = loadApp(Object.assign({ rootA: 'I1', rootB: 'P1', maxGen: '3', includeSiblings: true, ignoreLikelyAlive: false,
    categoryVisibility: { exact: true, similar: true } }, over));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  return a;
}
const shown = a => { const h = a._document.getElementById('report').innerHTML; return NAMES.filter(n => h.includes(n)); };
const total = a => { const h = a._document.getElementById('report').innerHTML;
  return [...h.matchAll(/class="card \w+"><div class="num">(\d+)</g)].reduce((t, m) => t + +m[1], 0); };

// Pattern parsing/matching
{
  const a = run({});
  const vis = (surnames, filter) => a.surnameVisible({ surnames }, a.parseSurnameFilter(filter));
  check(a.parseSurnameFilter(''), null, 'blank = no filter');
  check(a.parseSurnameFilter('  , ; '), null, 'only separators = no filter');
  check(vis(['Smith'], 'smith'), true, 'case-insensitive');
  check(vis(['Smith'], 'Smit'), false, 'whole surname, not substring');
  check(vis(['Smith'], 'Smi*'), true, 'trailing wildcard');
  check(vis(['Robinson'], '*son'), true, 'leading wildcard');
  check(vis(['Smith'], 'Jones, Smith'), true, 'comma list, any match');
  check(vis(['Smith'], 'Jones; Brown'), false, 'semicolon list, none match');
  check(vis(['Jones', 'Johns'], 'Johns'), true, 'matched pair qualifies if EITHER file matches');
  check(vis(['Smith'], "O'Smith"), false, 'punctuation ignored, but different name still differs');
  check(vis(['O\'Brien'], 'obrien'), true, 'punctuation in the recorded surname ignored');
  check(vis([''], 'Smith'), false, 'no surname never matches an active filter');
  check(vis(['Anything'], '*'), true, '"*" alone = any surname');
  check(vis(['Smith'], undefined), true, 'null patterns = visible');
}
for (const groupByAncestor of [true, false]) {
  const mode = groupByAncestor ? 'grouped' : 'flat';
  check(shown(run({ groupByAncestor })).length, 5, `${mode}: blank filter shows everyone`);
  check(shown(run({ groupByAncestor, surnameFilter: 'Smith' })), ['Root Smith', 'Dad Smith', 'Aunt Smith'], `${mode}: Smith (exact) excludes Smythe and Jones/Johns`);
  check(shown(run({ groupByAncestor, surnameFilter: 'Sm*' })), ['Root Smith', 'Dad Smith', 'Aunt Smith', 'Uncle Smythe'], `${mode}: Sm* includes Smythe`);
  check(shown(run({ groupByAncestor, surnameFilter: 'Johns' })), ['Catherine'], `${mode}: Johns finds the pair via the File B spelling`);
  check(shown(run({ groupByAncestor, surnameFilter: 'Jones' })), ['Catherine'], `${mode}: Jones finds the same pair via the File A spelling`);
  check(shown(run({ groupByAncestor, surnameFilter: 'Nobody' })), [], `${mode}: no match shows nothing`);
}
// Scope reduction: summary counts shrink; missing person out of scope not counted.
check(total(run({ surnameFilter: 'Smith' })) < total(run({})), true, 'summary counts shrink with the surname scope');
{
  const m = a => +a._document.getElementById('report').innerHTML.match(/class="card missing"><div class="num">(\d+)</)[1];
  check(m(run({})), 1, 'unfiltered: Uncle Smythe counted missing');
  check(m(run({ surnameFilter: 'Smith' })), 0, 'Smith only: missing Smythe out of scope, not counted');
  check(m(run({ surnameFilter: 'Smythe' })), 1, 'Smythe: the missing person is in scope');
}
// Combines with the distance limit (both must pass).
check(shown(run({ surnameFilter: 'Smith', generationLimit: '1' })), ['Root Smith', 'Dad Smith'], 'surname AND distance both apply');
// Grouped header colour ignores out-of-scope rows: Uncle Smythe (missing) would make Dad's section dark red.
{
  const hdr = over => { const h = run(over)._document.getElementById('report').innerHTML;
    const i = h.indexOf('Dad Smith'); return h.slice(0, i).match(/status-(\w+)"(?![\s\S]*status-\w+")/)[1]; };
  check(hdr({ groupByAncestor: true }), 'missing', 'unfiltered header reflects the missing uncle');
  check(hdr({ groupByAncestor: true, surnameFilter: 'Smith' }) !== 'missing', true, 'header ignores the out-of-scope missing uncle');
}
process.exit(summary('surname-filter'));
