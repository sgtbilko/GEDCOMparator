const { loadApp, check, summary } = require('../harness');

const gedA = `0 @A1@ INDI
1 NAME Unique /Person/
0 @A2@ INDI
1 NAME John /Smith/
1 BIRT
2 DATE 1850
0 @A3@ INDI
1 NAME Twin /Jones/
0 @A4@ INDI
1 NAME /Unnamed/
0 @A5@ INDI
1 NAME Mary /Brown/
1 BIRT
2 DATE 1900
`;
const gedB = `0 @B1@ INDI
1 NAME Unique /Person/
0 @B2@ INDI
1 NAME John /Smith/
1 BIRT
2 DATE 1820
0 @B3@ INDI
1 NAME John /Smith/
1 BIRT
2 DATE 1850
0 @B4@ INDI
1 NAME Twin /Jones/
1 BIRT
2 DATE 1700
0 @B5@ INDI
1 NAME Twin /Jones/
1 BIRT
2 DATE 1701
0 @B6@ INDI
1 NAME Mary /Brown/
1 BIRT
2 DATE 1900
0 @B7@ INDI
1 NAME Mary /Brown/
1 BIRT
2 DATE 1900
`;
const app = loadApp({});
app.loadGedcomFiles(gedA, gedB);
const dataA = app.getVar('dataA'), dataB = app.getVar('dataB');
const find = id => { const r = app.findCounterpartInOtherFile(dataA.individuals[id], dataB); return r ? r.id : null; };

check(find('A1'), 'B1', 'unique name -> that person');
check(find('A2'), 'B3', 'same name twice -> narrowed by birth year');
check(find('A3'), null, 'same name twice, no year on the A side -> ambiguous, null');
check(find('A4'), null, 'surname-only name has no counterpart -> null');
check(find('A5'), null, 'same name AND same year twice -> still ambiguous, null');
check(app.findCounterpartInOtherFile(null, dataB), null, 'null individual -> null');
// Re-parsing File B makes a new data object, so a stale index can never be used.
app.loadGedcomFiles(gedA, gedB.replace('NAME Unique /Person/', 'NAME Someone /Else/'));
check(app.findCounterpartInOtherFile(dataA.individuals.A1, app.getVar('dataB')), null, 'after a re-parse the old index is not reused');
process.exit(summary('name-index'));
