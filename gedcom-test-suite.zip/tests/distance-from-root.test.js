// Distance from root person (v47): siblings count as ONE step.
const { loadApp, check, summary } = require('../harness');
const app = loadApp();
const { distanceFromRoot } = app;

check(distanceFromRoot('Ancestor', ''), 0, 'root = 0');
check(distanceFromRoot('Ancestor', 'F'), 1, 'parent = 1');
check(distanceFromRoot('Ancestor', 'FMF'), 3, 'great-grandparent = 3');
check(distanceFromRoot('Sibling', ''), 1, "root's sibling = 1 (not 2)");
check(distanceFromRoot('Sibling', 'F'), 2, "parent's sibling (uncle) = 2 (not 3)");
check(distanceFromRoot('Sibling', 'FF'), 3, "grandparent's sibling = 3");
check(distanceFromRoot('Spouse', ''), 1, "root's spouse = 1");
check(distanceFromRoot('Spouse', 'F'), 2, "parent's spouse = 2");
check(distanceFromRoot("Sibling's spouse", ''), 2, "root's sibling's spouse = 2");
check(distanceFromRoot("Sibling's spouse", 'F'), 3, "uncle's spouse = 3");
check(distanceFromRoot('Child', ''), 1, "root's child = 1");
check(distanceFromRoot('Grandchild', ''), 2, "root's grandchild = 2");
check(distanceFromRoot('Great-grandchild', ''), 3, "root's great-grandchild = 3");
check(distanceFromRoot('Great-great-grandchild', ''), 4, "root's 2x great-grandchild = 4");
check(distanceFromRoot('Child', 'F'), 1, "parent's other child (half-sibling) = 1");
check(distanceFromRoot('Grandchild', 'F'), 2, "half-sibling's child = 2");
check(distanceFromRoot('Child', 'FF'), 2, "grandparent's other child (uncle) = 2");
check(distanceFromRoot('Bogus', ''), null, 'unknown role -> null');

// End-to-end: rows carry distance and it renders.
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Sib /Person/
1 FAMC @F1@
0 @I4@ INDI
1 NAME Uncle /Person/
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @I2@
1 CHIL @I1@
1 CHIL @I3@
0 @F2@ FAM
1 CHIL @I2@
1 CHIL @I4@
`;
const gedB = gedA.replace(/@I(\d)@/g, '@P$1@').replace(/@F(\d)@/g, '@G$1@');
const a = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, ignoreLikelyAlive: false, categoryVisibility: { exact: true } });
a.loadGedcomFiles(gedA, gedB);
a.runCompare();
const byRole = {};
for (const s of a.getVar('lastSections')) for (const r of s.rows) byRole[`${s.code}|${r.role}|${r.name}`] = r.distance;
check(byRole['|Sibling|Sib Person'], 1, 'row: root sibling distance 1');
check(byRole['F|Sibling|Uncle Person'], 2, 'row: uncle distance 2');
check(byRole['F|Ancestor|Dad Person'], 1, 'row: father distance 1');
const html = a._document.getElementById('report').innerHTML;
check(html.includes('generation 1 · distance 1'), true, 'grouped header shows generation and distance');
check(/distance 2/.test(html), true, 'card shows distance 2 tag');
const flat = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, ignoreLikelyAlive: false, groupByAncestor: false, categoryVisibility: { exact: true } });
flat.loadGedcomFiles(gedA, gedB);
flat.runCompare();
check(/Sibling · distance 2/.test(flat._document.getElementById('report').innerHTML), true, 'flat header shows role and distance');
process.exit(summary('distance-from-root'));
