// v54: the Similarity and Display settings panels start collapsed and carry a
// chevron toggle; the "within N steps" control is a 1-12 + All dropdown.
const fs = require('fs'), path = require('path');
const { check, summary } = require('../harness');
const html = fs.readFileSync(path.join(__dirname, '..', 'GEDCOMparator.html'), 'utf8');

for (const id of ['reportControlsSimilarity', 'reportControls']) {
  const tag = html.match(new RegExp(`<div class="([^"]*)" id="${id}"`));
  check(!!tag && tag[1].split(' ').includes('panel-collapsed'), true, `${id} starts collapsed`);
}
check((html.match(/class="panel-toggle"/g) || []).length, 2, 'both panels have a chevron toggle in the heading');
check(/\.report-controls\.panel-collapsed > \*:not\(h2\) \{ display: none !important; \}/.test(html), true, 'collapsed CSS hides everything but the heading');

// togglePanel flips the class and aria-expanded on the panel.
{
  const classes = new Set(['report-controls', 'panel-collapsed']);
  const panel = { classList: { toggle: c => (classes.has(c) ? (classes.delete(c), false) : (classes.add(c), true)) } };
  const attrs = {};
  const btn = { closest: () => panel, setAttribute: (k, v) => { attrs[k] = v; } };
  const fn = new Function('btnEl', html.match(/function togglePanel\(btnEl\) \{([\s\S]*?)\n\}/)[1]);
  fn(btn); check([classes.has('panel-collapsed'), attrs['aria-expanded']], [false, 'true'], 'first click expands');
  fn(btn); check([classes.has('panel-collapsed'), attrs['aria-expanded']], [true, 'false'], 'second click collapses');
}

// Distance-limit dropdown: options 1..12 then All, default 7; no old checkbox.
{
  const sel = html.match(/<select id="generationLimit"[^>]*>([\s\S]*?)<\/select>/)[1];
  const vals = [...sel.matchAll(/<option value="([^"]+)"/g)].map(m => m[1]);
  check(vals, [...Array(12).keys()].map(i => String(i + 1)).concat('all'), 'options are 1-12 then All');
  check(/<option value="7" selected>/.test(sel), true, 'default is 7');
  check(html.includes('id="limitGenerations"'), false, 'old on/off checkbox is gone');
}
// The dropdown must not inherit the full-width select rule inside the settings panels.
check(/\.report-controls select\.gen-select \{ width: auto;/.test(html), true, 'distance dropdown is compact (auto width) like the generations dropdowns');
process.exit(summary('panel-collapse'));
