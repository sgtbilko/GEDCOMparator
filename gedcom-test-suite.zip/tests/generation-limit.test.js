// "Only show people within N generations" display filter (v48).
const { loadApp, check, summary } = require('../harness');

// Chain: Root <- Dad <- Grandad <- GreatGrandad, all in both files; a sibling
// of Greatgrandad (Greatuncle, generation 3) present only in A so it shows as a missing row.
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Grandad /Person/
1 FAMS @F2@
1 FAMC @F3@
0 @I4@ INDI
1 NAME Greatgrandad /Person/
1 FAMS @F3@
1 FAMC @F4@
0 @I5@ INDI
1 NAME Greatuncle /Person/
1 BIRT
2 DATE 1800
1 FAMC @F4@
0 @F1@ FAM
1 HUSB @I2@
1 CHIL @I1@
0 @F2@ FAM
1 HUSB @I3@
1 CHIL @I2@
0 @F3@ FAM
1 HUSB @I4@
1 CHIL @I3@
0 @F4@ FAM
1 CHIL @I4@
1 CHIL @I5@
`;
const gedB = gedA.replace(/@I(\d)@/g, '@P$1@').replace(/@F(\d)@/g, '@G$1@')
  .replace(/0 @P5@ INDI[\s\S]*?(?=0 @G1@)/, '').replace(/1 CHIL @P5@\n/g, '');

function labels(app) {
  const html = app._document.getElementById('report').innerHTML;
  return ['Root Person', 'Dad Person', 'Grandad Person', 'Greatgrandad Person', 'Greatuncle Person'].filter(n => html.includes(n));
}
const base = { rootA: 'I1', rootB: 'P1', maxGen: '6', includeSiblings: true, ignoreLikelyAlive: false, categoryVisibility: { exact: true } };

{
  const a = loadApp(Object.assign({}, base));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a), ['Root Person', 'Dad Person', 'Grandad Person', 'Greatgrandad Person', 'Greatuncle Person'], 'default N=7: everything shown');
}
{
  const a = loadApp(Object.assign({}, base, { generationLimit: '1' }));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a), ['Root Person', 'Dad Person'], 'N=1: root and parents only');
}
{
  const a = loadApp(Object.assign({}, base, { generationLimit: '0' }));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a), ['Root Person'], 'N=0: root section only');
}
{
  const a = loadApp(Object.assign({}, base, { generationLimit: '2' }));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a), ['Root Person', 'Dad Person', 'Grandad Person'], 'N=2 drops generation 3 sections');
}
{
  // Counts shrink with the scope: great-uncle is missing from B (1 missing) at gen 3.
  const wide = loadApp(Object.assign({}, base));
  wide.loadGedcomFiles(gedA, gedB); wide.runCompare();
  const narrow = loadApp(Object.assign({}, base, { generationLimit: '2' }));
  narrow.loadGedcomFiles(gedA, gedB); narrow.runCompare();
  const missingCount = app => +app._document.getElementById('report').innerHTML.match(/class="card missing"><div class="num">(\d+)</)[1];
  check(missingCount(wide), 1, 'N=7: missing person counted');
  check(missingCount(narrow), 0, 'N=2: out-of-scope missing person not counted');
}
{
  const a = loadApp(Object.assign({}, base, { generationLimit: '1', limitGenerations: false }));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a).length, 5, 'checkbox off: no limit regardless of N');
}
{
  const a = loadApp(Object.assign({}, base, { generationLimit: '', groupByAncestor: false }));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  check(labels(a).length, 5, 'blank N (flat mode): no limit');
  const b = loadApp(Object.assign({}, base, { generationLimit: '1', groupByAncestor: false }));
  b.loadGedcomFiles(gedA, gedB); b.runCompare();
  check(labels(b), ['Root Person', 'Dad Person'], 'flat mode honours the limit too');
}
process.exit(summary('generation-limit'));
