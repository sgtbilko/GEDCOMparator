// "Only show people within N steps of the root" display filter (v48, reworked v53).
// v53: N is compared with each person's DISTANCE from the root (the figure
// displayed on their entry), NOT the generation of the ancestor section they
// are listed under.
const { loadApp, check, summary } = require('../harness');

// Root(0) <- Dad (dist 1) <- Grandad (dist 2, gen 2).
// Grandma is Dad's mother (direct ancestor, dist 2, her own section).
// Grandad's section also holds: Uncle (sibling, dist 3) and Missinguncle
// (sibling, dist 3, only in A). Dad's section: Auntie (sibling, dist 2).
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Grandad /Person/
1 SEX M
1 FAMS @F2@
1 FAMS @F5@
1 FAMC @F3@
0 @I4@ INDI
1 NAME Uncle /Person/
1 FAMC @F3@
0 @I5@ INDI
1 NAME Missinguncle /Person/
1 BIRT
2 DATE 1800
1 FAMC @F3@
0 @I6@ INDI
1 NAME Grandma /Person/
1 SEX F
1 FAMS @F2@
0 @I7@ INDI
1 NAME Auntie /Person/
1 FAMC @F2@
0 @I8@ INDI
1 NAME Greatgrandad /Person/
1 SEX M
1 FAMS @F3@
0 @F1@ FAM
1 HUSB @I2@
1 CHIL @I1@
0 @F2@ FAM
1 HUSB @I3@
1 WIFE @I6@
1 CHIL @I2@
1 CHIL @I7@
0 @F3@ FAM
1 HUSB @I8@
1 CHIL @I3@
1 CHIL @I4@
1 CHIL @I5@
`.replace(/1 FAMS @F5@\n/, '');
const gedB = gedA.replace(/@I(\d)@/g, '@P$1@').replace(/@F(\d)@/g, '@G$1@')
  .replace(/0 @P5@ INDI[\s\S]*?(?=0 @P6@)/, '').replace(/1 CHIL @P5@\n/g, '');

const NAMES = ['Root Person', 'Dad Person', 'Auntie Person', 'Grandad Person', 'Grandma Person', 'Uncle Person', 'Missinguncle Person', 'Greatgrandad Person'];
function shown(app) {
  const html = app._document.getElementById('report').innerHTML;
  return NAMES.filter(n => html.includes(n));
}
const base = { rootA: 'I1', rootB: 'P1', maxGen: '6', includeSiblings: true, includeAncestorSpouses: true,
  ignoreLikelyAlive: false, categoryVisibility: { exact: true } };
function run(over) {
  const a = loadApp(Object.assign({}, base, over));
  a.loadGedcomFiles(gedA, gedB); a.runCompare();
  return a;
}
const missingCount = app => +app._document.getElementById('report').innerHTML.match(/class="card missing"><div class="num">(\d+)</)[1];

// Sanity: the distances the filter relies on.
{
  const a = run({});
  const rows = a.getVar('lastSections').flatMap(s => s.rows);
  const d = n => rows.find(r => r.name === n).distance;
  check([d('Root Person'), d('Dad Person'), d('Auntie Person'), d('Grandad Person'), d('Uncle Person'), d('Grandma Person'), d('Greatgrandad Person')],
        [0, 1, 2, 2, 3, 2, 3], 'fixture distances as expected');
}
for (const groupByAncestor of [true, false]) {
  const mode = groupByAncestor ? 'grouped' : 'flat';
  check(shown(run({ groupByAncestor })).length, NAMES.length, `${mode}: default N=7 shows everyone`);
  check(shown(run({ groupByAncestor, generationLimit: '0' })), ['Root Person'], `${mode}: N=0 root only`);
  check(shown(run({ groupByAncestor, generationLimit: '1' })), ['Root Person', 'Dad Person'], `${mode}: N=1`);
  // KEY v53 behaviour: Grandad's section is generation 2, but his sibling/spouse
  // sit at distance 3 and must be dropped at N=2 even though Grandad stays.
  check(shown(run({ groupByAncestor, generationLimit: '2' })), ['Root Person', 'Dad Person', 'Auntie Person', 'Grandad Person', 'Grandma Person'],
        `${mode}: N=2 keeps Grandad/Grandma/Auntie (2) but drops Grandad's siblings (3) and Greatgrandad (3)`);
  check(shown(run({ groupByAncestor, generationLimit: '3' })).length, NAMES.length, `${mode}: N=3 shows everyone (max distance 3)`);
}
{
  // Counts shrink with the scope: Missinguncle (distance 3) is the one missing person.
  check(missingCount(run({})), 1, 'N=7: missing person counted');
  check(missingCount(run({ generationLimit: '3' })), 1, 'N=3: still in scope');
  check(missingCount(run({ generationLimit: '2' })), 0, 'N=2: distance-3 missing person out of scope, not counted');
}
{
  check(shown(run({ generationLimit: '1', limitGenerations: false })).length, NAMES.length, 'checkbox off: no limit regardless of N');
  check(shown(run({ generationLimit: '', groupByAncestor: false })).length, NAMES.length, 'blank N: no limit');
}
{
  // Grouped-mode header colour ignores out-of-scope rows: Missinguncle would turn
  // Grandad's header "missing" (deep red), but at N=2 he is out of scope.
  const status = over => {
    const html = run(over)._document.getElementById('report').innerHTML;
    const i = html.indexOf('Grandad Person');
    return html.slice(0, i).match(/status-(\w+)"(?![\s\S]*status-\w+")/)[1];
  };
  check(status({ groupByAncestor: true, generationLimit: '7' }), 'missing', 'header shows missing when the missing sibling is in scope');
  check(status({ groupByAncestor: true, generationLimit: '2' }), 'exact', 'header ignores the out-of-scope missing sibling');
}
process.exit(summary('generation-limit'));
