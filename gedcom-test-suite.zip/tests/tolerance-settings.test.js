// Tests the "Similarity settings" panel: Location tolerance (a single slider
// folding in the old "hide matches with similar locations" checkbox +
// threshold), Name tolerance (live as of v41, having been compare-time-only
// since v39), and Date tolerance (live, like Location tolerance, as of v40).
// All three sliders are now live: none of them require a re-compare to
// change what an already-generated report shows.
const { loadApp, check, summary } = require('../harness');

// ---------- datesMatch(a, b, toleranceDays) ----------
{
  const app = loadApp();
  const { datesMatch } = app;
  check(datesMatch('Jun 1900', 'Sep 1900'), false,
    'date tolerance: ~92 days apart, default (91-day) tolerance — not a match');
  check(datesMatch('Jun 1900', 'Sep 1900', 120), true,
    'date tolerance: same dates, wider 120-day tolerance — now a match');
  check(datesMatch('Jun 1900', 'Sep 1900', 0), false,
    'date tolerance: same dates, 0-day tolerance — still not a match');
  check(datesMatch('12 Jan 1900', '13 Jan 1900', 365), false,
    'date tolerance: an EXACT (full day/month/year) date on either side is never widened by the tolerance setting, however large');
  check(datesMatch('', ''), true, 'date tolerance: both blank still matches regardless of tolerance');
}

// ---------- isMinorSpellingVariant(a, b, maxDistance) / nameSubstantiallyDifferent ----------
{
  const app = loadApp();
  const { isMinorSpellingVariant, nameSubstantiallyDifferent } = app;
  check(isMinorSpellingVariant('smith', 'smyth'), true, 'name tolerance: default threshold (2) still allows a 1-edit variant');
  check(isMinorSpellingVariant('roberts', 'robbins'), false, 'name tolerance: default threshold (2) rejects a 3-edit variant');
  check(isMinorSpellingVariant('roberts', 'robbins', 3), true, 'name tolerance: raising the threshold to 3 now allows that same 3-edit variant');
  check(isMinorSpellingVariant('smith', 'smyth', 0), false, 'name tolerance: lowering the threshold to 0 requires an identical string');

  function name(given, surname) { return { given, surname, full: `${given} ${surname}`.trim() }; }
  check(nameSubstantiallyDifferent(name('John', 'Roberts'), name('John', 'Robbins')), true,
    'name tolerance: default threshold flags a 3-edit surname as substantially different');
  check(nameSubstantiallyDifferent(name('John', 'Roberts'), name('John', 'Robbins'), 3), false,
    'name tolerance: a raised threshold (3) no longer flags that same surname pair');
}

// ---------- end-to-end: Name tolerance is now live too (v41) ----------
// Same fixture shape as the "Date tolerance is now live" block further down:
// the row itself carries no baked substantiallyDifferent flag any more, so
// checking it against a different tolerance — or widening the slider and
// re-rendering with NO second runCompare() — proves the check is genuinely
// re-run fresh each time rather than fixed at compare time.
{
  const gedA = `0 @I1@ INDI
1 NAME John /Roberts/
1 FAMS @F1@
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
  const gedB = `0 @P1@ INDI
1 NAME John /Robbins/
1 FAMS @G1@
0 @P2@ INDI
1 NAME Jane /Doe/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P1@
1 WIFE @P2@
`;

  const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1' }); // default nameTolerance: 2
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  const root = app.getVar('lastSections').find(s => s.label === 'Root');
  const ancestorHeader = root.ancestorHeader;

  // Same row, two different tolerance values, no re-compare in between —
  // the whole point of making this live.
  check(app.rowSubstantiallyDifferent(ancestorHeader, 2), true,
    'name tolerance (live): at the default threshold (2), Roberts/Robbins (3-edit) is flagged substantially different');
  check(app.rowSubstantiallyDifferent(ancestorHeader, 3), false,
    'name tolerance (live): the SAME row, re-checked at threshold 3 with no re-compare, is no longer flagged');

  // And the same liveness shows up end-to-end through the actual rendered
  // report: change only the slider, then re-render with no second runCompare().
  app.renderReport();
  const reportBefore = app._document._el('report').innerHTML;
  check(reportBefore.includes('badge substantial-diff'), true,
    'name tolerance (live, report): at the default tolerance, the rendered report flags the Roberts/Robbins pair');

  app._document._el('nameTolerance').value = '3';
  app.renderReport();
  const reportAfter = app._document._el('report').innerHTML;
  check(reportAfter.includes('badge substantial-diff'), false,
    'name tolerance (live, report): widening the slider to 3 — with no re-compare — no longer flags it in the rendered report');
}

// ---------- Location tolerance: 0% behaves exactly like the old checkbox unchecked ----------
{
  const { matchExactness, rowHasEffectiveDiff } = loadApp();
  const placeField = { label: 'Birth place', a: 'Torgau, Germany', b: 'Germany', same: false, type: 'place', similarity: 0.6 };
  const row = { status: 'both', fieldDiffs: [placeField] };
  check(rowHasEffectiveDiff(row, true, 0.5), false, 'location tolerance: at 50% (tolerance > 0), a 0.6-similarity place pair counts as matching');
  check(rowHasEffectiveDiff(row, false, 0.5), true, 'location tolerance: at 0% (mapped to ignoreSimilarLocations=false), that same pair is a real diff');
  check(matchExactness(row, false, 0.5), 'exact', 'location tolerance: at 0%, matchExactness never classifies it as merely "similar"');
}

// ---------- Date tolerance is now live, like Location tolerance (v40) ----------
// Same fixture as the end-to-end block above, but this time the tolerance
// slider is changed AFTER runCompare() and only renderReport() is called
// again — proving the day-window is re-applied on every render rather than
// baked in once at "Compare trees" time.
{
  const gedA = `0 @I1@ INDI
1 NAME John /Roberts/
1 FAMS @F1@
1 BIRT
2 DATE Jun 1900
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
  const gedB = `0 @P1@ INDI
1 NAME John /Roberts/
1 FAMS @G1@
1 BIRT
2 DATE Sep 1900
0 @P2@ INDI
1 NAME Jane /Doe/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P1@
1 WIFE @P2@
`;
  const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1' }); // default dateTolerance: 91
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  app.renderReport();
  const reportBefore = app._document._el('report').innerHTML;
  check(reportBefore.includes('diff-cell'), true,
    'date tolerance (live): at the default 91-day tolerance, the ~92-day birth-date gap renders as a real diff');
  check(reportBefore.includes('dates recognized as equivalent'), false,
    'date tolerance (live): ...and is not shown as an equivalent-date match');

  // No second runCompare() — only the slider changes, then the report is
  // re-rendered against the same lastSections from the single compare above.
  app._document._el('dateTolerance').value = '120';
  app.renderReport();
  const reportAfter = app._document._el('report').innerHTML;
  check(reportAfter.includes('dates recognized as equivalent'), true,
    'date tolerance (live): widening the slider to 120 days — with no re-compare — now shows that same birth-date pair as equivalent');
}

process.exit(summary('tolerance-settings'));
