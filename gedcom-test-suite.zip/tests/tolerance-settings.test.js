// Tests the "Similarity settings" panel: Location tolerance (a single slider
// folding in the old "hide matches with similar locations" checkbox +
// threshold), Name tolerance (a % of letters as of v42; live since v41), and
// Date tolerance (live, like Location tolerance, as of v40).
// All three sliders are now live: none of them require a re-compare to
// change what an already-generated report shows.
const { loadApp, check, summary } = require('../harness');

// ---------- datesMatch(a, b, toleranceDays) ----------
{
  const app = loadApp();
  const { datesMatch } = app;
  check(datesMatch('Jun 1900', 'Sep 1900'), false,
    'date tolerance: ~92 days apart, default (91-day) tolerance — not a match');
  check(datesMatch('Jun 1900', 'Sep 1900', 120), true,
    'date tolerance: same dates, wider 120-day tolerance — now a match');
  check(datesMatch('Jun 1900', 'Sep 1900', 0), false,
    'date tolerance: same dates, 0-day tolerance — still not a match');
  check(datesMatch('12 Jan 1900', '13 Jan 1900', 365), false,
    'date tolerance: an EXACT (full day/month/year) date on either side is never widened by the tolerance setting, however large');
  check(datesMatch('', ''), true, 'date tolerance: both blank still matches regardless of tolerance');
}

// ---------- Name tolerance: ratio of letters (v42) ----------
{
  const app = loadApp();
  const { nameRatio, classifyName, nameSubstantiallyDifferent } = app;
  function name(given, surname) { return { given, surname, full: `${given} ${surname}`.trim() }; }
  check(nameRatio('smith', 'smyth'), 0.2, 'name tolerance: one edit in a 5-letter name is a 20% distance');
  check(nameRatio('smith', 'smith'), 0, 'name tolerance: identical strings are 0');
  check(nameRatio('', 'smith'), null, 'name tolerance: a blank side is missing data, not a distance');

  // Roberts/Robbins: 3 edits over 7 letters = ~42.9%
  const roberts = name('John', 'Roberts'), robbins = name('John', 'Robbins');
  check(classifyName(roberts, robbins, 0.10), 'substantial', 'name tolerance: at 10% (red bar 30%) Roberts/Robbins (43%) is substantially different');
  check(classifyName(roberts, robbins, 0.15), 'different', 'name tolerance: at the 15% default (red bar 45%) the same pair is only "different"');
  check(classifyName(roberts, robbins, 0.20), 'different', 'name tolerance: at 20% (red bar 60%) still "different" — 43% is above the 20% similar bar');
  check(classifyName(roberts, robbins, 0.45), 'similar', 'name tolerance: at 45% the same pair is finally "similar"');
  check(classifyName(name('John', 'Smith'), name('JOHN', 'SMITH'), 0), 'exact', 'name tolerance: identical ignoring case is exact at any tolerance');
  check(nameSubstantiallyDifferent(roberts, robbins), false, 'name tolerance: omitted tolerance falls back to the 15% default');
}

// ---------- Location tolerance: 0% means exact-only (ignoreSimilarLocations=false) ----------
{
  const { matchExactness, rowHasEffectiveDiff } = loadApp();
  const placeField = { label: 'Birth place', a: 'Torgau, Germany', b: 'Germany', same: false, type: 'place', similarity: 0.6 };
  const row = { status: 'both', fieldDiffs: [placeField] };
  check(rowHasEffectiveDiff(row, true, 0.5), false, 'location tolerance: at 50% (tolerance > 0), a 0.6-similarity place pair counts as matching');
  check(rowHasEffectiveDiff(row, false, 0.5), true, 'location tolerance: at 0% (mapped to ignoreSimilarLocations=false), that same pair is a real diff');
  check(matchExactness(row, false, 0.5), 'exact', 'location tolerance: at 0%, matchExactness never classifies it as merely "similar"');
}

// ---------- Date tolerance is now live, like Location tolerance (v40) ----------
// Same fixture as the end-to-end block above, but this time the tolerance
// slider is changed AFTER runCompare() and only renderReport() is called
// again — proving the day-window is re-applied on every render rather than
// baked in once at "Compare trees" time.
{
  const gedA = `0 @I1@ INDI
1 NAME John /Roberts/
1 FAMS @F1@
1 BIRT
2 DATE Jun 1900
0 @I2@ INDI
1 NAME Jane /Doe/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
  const gedB = `0 @P1@ INDI
1 NAME John /Roberts/
1 FAMS @G1@
1 BIRT
2 DATE Sep 1900
0 @P2@ INDI
1 NAME Jane /Doe/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P1@
1 WIFE @P2@
`;
  const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { similar: true } }); // default dateTolerance: 91
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  app.renderReport();
  const reportBefore = app._document._el('report').innerHTML;
  check(reportBefore.includes('diff-cell'), true,
    'date tolerance (live): at the default 91-day tolerance, the ~92-day birth-date gap renders as a real diff');
  check(reportBefore.includes('dates recognized as equivalent'), false,
    'date tolerance (live): ...and is not shown as an equivalent-date match');

  // No second runCompare() — only the slider changes, then the report is
  // re-rendered against the same lastSections from the single compare above.
  app._document._el('dateTolerance').value = '120';
  app.renderReport();
  const reportAfter = app._document._el('report').innerHTML;
  check(reportAfter.includes('dates recognized as equivalent'), true,
    'date tolerance (live): widening the slider to 120 days — with no re-compare — now shows that same birth-date pair as equivalent');
}

process.exit(summary('tolerance-settings'));
