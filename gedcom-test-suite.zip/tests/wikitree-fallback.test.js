// Tests findNearestWikiTreeUrl's breadth-first "closest by number of steps"
// search: children and parents (blood, one step away) are always checked
// ahead of a spouse (also one step, but by marriage) found at the same
// depth; beyond that, each step outward is only explored once the previous
// step has come up completely empty, so siblings, grandparents, in-laws,
// grandchildren etc. all naturally fall out in genuine minimum-steps order
// rather than a fixed list of relationship types. Each step is checked
// across BOTH files before moving further out. Built with small synthetic
// data objects (matching extractIndividual's shape) rather than GEDCOM text,
// since findNearestWikiTreeUrl operates directly on parsed data and doesn't
// need a real file round-trip.
const { loadApp, check, summary } = require('../harness');

const app = loadApp();
const { findNearestWikiTreeUrl } = app;

function ind(id, opts = {}) {
  return {
    id,
    name: { given: opts.given || id, surname: opts.surname || 'Test', full: `${opts.given || id} ${opts.surname || 'Test'}` },
    sex: opts.sex || '',
    birth: { date: opts.birthDate || '', place: '' },
    death: { date: '', place: '' },
    famc: opts.famc || [],
    fams: opts.fams || [],
    links: opts.links || []
  };
}
function wikiLink(n) { return [{ url: `https://www.wikitree.com/wiki/Person-${n}`, label: 'WikiTree' }]; }
function fam(id, husb, wife, chil) { return { id, husb: husb || null, wife: wife || null, chil: chil || [], marr: { date: '', place: '' } }; }
function emptyData() { return { individuals: {}, families: {} }; }

// --- Blood (parent) beats spouse at the same depth (one step away) ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'], famc: ['FPARENT'] });
  dataA.individuals.spouse = ind('spouse', { links: wikiLink(1) });
  dataA.individuals.kid = ind('kid'); // no link
  dataA.individuals.parent = ind('parent', { links: wikiLink(2) });
  dataA.families.F1 = fam('F1', 'target', 'spouse', ['kid']);
  dataA.families.FPARENT = fam('FPARENT', 'parent', null, ['target']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-2',
    "a parent (blood, one step) wins over a spouse (also one step, but by marriage) even though the spouse's link would otherwise be found");
}

// --- Blood (child) beats spouse at the same depth too ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.spouse = ind('spouse', { links: wikiLink(3) });
  dataA.individuals.kid = ind('kid', { links: wikiLink(4) });
  dataA.families.F1 = fam('F1', 'target', 'spouse', ['kid']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-4',
    'a child (blood, one step) wins over a spouse (also one step) too');
}

// --- Within blood at the same depth, a child is checked ahead of a parent ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { famc: ['FPARENT'] });
  dataA.individuals.target.fams = ['F1'];
  dataA.individuals.kid = ind('kid', { links: wikiLink(5) });
  dataA.individuals.parent = ind('parent', { links: wikiLink(6) });
  dataA.families.F1 = fam('F1', 'target', null, ['kid']);
  dataA.families.FPARENT = fam('FPARENT', 'parent', null, ['target']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-5',
    'a child is checked ahead of a parent when both are one step away and both have a link');
}

// --- Nothing at depth 1: falls through to a grandchild at depth 2 ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.kid = ind('kid', { fams: ['F2'] }); // no link
  dataA.individuals.grandkid = ind('grandkid', { links: wikiLink(7) });
  dataA.families.F1 = fam('F1', 'target', null, ['kid']);
  dataA.families.F2 = fam('F2', 'kid', null, ['grandkid']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-7',
    'falls through to a grandchild at depth 2 when nothing at depth 1 has a link');
}

// --- A sibling (via the shared parent) is reachable at all - but only as a
// last resort: see the "direct line first" block further down, which pins
// down that any ancestor/descendant with a link outranks it ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { famc: ['FPARENT'] });
  dataA.individuals.sibling = ind('sibling', { famc: ['FPARENT'], links: wikiLink(8) });
  dataA.individuals.parent = ind('parent', { fams: ['FPARENT'] }); // no link — forces depth 2
  dataA.families.FPARENT = fam('FPARENT', 'parent', null, ['target', 'sibling']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-8',
    'a sibling (2 steps via the shared parent) is found — a relation the old fixed-tier list never reached at all');
}

// --- New capability: a grandparent (2 steps) ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { famc: ['FPARENT'] });
  dataA.individuals.parent = ind('parent', { famc: ['FGRANDPARENT'] }); // no link
  dataA.individuals.grandparent = ind('grandparent', { links: wikiLink(9) });
  dataA.families.FPARENT = fam('FPARENT', 'parent', null, ['target']);
  dataA.families.FGRANDPARENT = fam('FGRANDPARENT', 'grandparent', null, ['parent']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-9',
    'a grandparent (2 steps) is found when nothing at depth 1 has a link');
}

// --- New capability: an in-law via the spouse (spouse's own parent, 2 steps) ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.spouse = ind('spouse', { famc: ['FSPOUSEPARENT'] }); // no link of her own
  dataA.individuals.spouseParent = ind('spouseParent', { links: wikiLink(10) });
  dataA.families.F1 = fam('F1', 'target', 'spouse', []);
  dataA.families.FSPOUSEPARENT = fam('FSPOUSEPARENT', 'spouseParent', null, ['spouse']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-10',
    "an in-law — the spouse's own parent, 2 steps away — is found once depth 1 comes up empty");
}

// --- A step is checked across BOTH files before moving further out: a File B
// blood relative at depth 1 wins over a File A spouse also at depth 1 ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.spouse = ind('spouse', { links: wikiLink(11) }); // depth 1, File A, marriage
  dataA.families.F1 = fam('F1', 'target', 'spouse', []);

  const dataB = emptyData();
  dataB.individuals.targetB = ind('targetB', { famc: ['GPARENT'] });
  dataB.individuals.parentB = ind('parentB', { links: wikiLink(12) }); // depth 1, File B, blood
  dataB.families.GPARENT = fam('GPARENT', 'parentB', null, ['targetB']);

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', 'targetB'), 'https://www.wikitree.com/wiki/Person-12',
    "a File B parent (blood, depth 1) wins over a File A spouse (marriage, depth 1) — blood always outranks marriage at an equal depth, regardless of which file it's found in");
}

// --- Cross-file counterpart fallback (unaffected by the BFS rewrite) ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.spouseA = ind('spouseA', { given: 'Jane', surname: 'Doe', birthDate: '1900' }); // no link of her own
  dataA.families.F1 = fam('F1', 'target', 'spouseA', []);

  const dataB = emptyData();
  // Jane Doe's counterpart in File B (same normalized name + birth year) DOES have a link.
  dataB.individuals.spouseB = ind('spouseB', { given: 'Jane', surname: 'Doe', birthDate: '1900', links: wikiLink(13) });

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), 'https://www.wikitree.com/wiki/Person-13',
    "a spouse with no WikiTree link of her own still surfaces one via her counterpart in the other file");
}

// --- Cross-file counterpart lookup refuses an ambiguous name collision ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'] });
  dataA.individuals.spouseA = ind('spouseA', { given: 'Jane', surname: 'Doe' }); // no birth year to disambiguate
  dataA.families.F1 = fam('F1', 'target', 'spouseA', []);

  const dataB = emptyData();
  dataB.individuals.jane1 = ind('jane1', { given: 'Jane', surname: 'Doe', links: wikiLink(14) });
  dataB.individuals.jane2 = ind('jane2', { given: 'Jane', surname: 'Doe' }); // a second, different Jane Doe

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), null,
    'an ambiguous same-name counterpart (two candidates, no way to pick) is never guessed at');
}

// --- Never walks back to where it came from (no infinite loop via a parent/
// child/spouse cycle) ---
{
  const dataA = emptyData();
  dataA.individuals.target = ind('target', { fams: ['F1'], famc: ['FPARENT'] });
  dataA.individuals.spouse = ind('spouse', { fams: ['F1'] }); // no link anywhere
  dataA.individuals.parent = ind('parent'); // no link anywhere
  dataA.families.F1 = fam('F1', 'target', 'spouse', []);
  dataA.families.FPARENT = fam('FPARENT', 'parent', null, ['target']);
  const dataB = emptyData();

  check(findNearestWikiTreeUrl(dataA, dataB, 'target', null), null,
    'a small, fully-explored family with no WikiTree link anywhere returns null rather than looping or throwing');
}

// --- Nothing anywhere: null, not a thrown error ---
{
  const dataA = emptyData();
  dataA.individuals.lonely = ind('lonely');
  const dataB = emptyData();
  check(findNearestWikiTreeUrl(dataA, dataB, 'lonely', null), null, 'no WikiTree link anywhere in scope returns null, not an error');
}


// ===================================================================
// Direct line first (v49): children/parents, then grandchildren/
// grandparents, and so on outward; siblings only if NOBODY in the direct
// line has a link.
// ===================================================================
function sibFamily(withSiblingLink) {
  // target + sibling share FP (parent p, who has no link). p descends from gp (FG) from ggp (FGG).
  const d = emptyData();
  d.individuals.t = ind('t', { famc: ['FP'], fams: ['FK'] });
  d.individuals.sib = ind('sib', { famc: ['FP'], links: withSiblingLink ? wikiLink(100) : [] });
  d.individuals.p = ind('p', { famc: ['FG'], fams: ['FP'] });
  d.individuals.gp = ind('gp', { famc: ['FGG'], fams: ['FG'] });
  d.individuals.ggp = ind('ggp', { fams: ['FGG'] });
  d.individuals.k = ind('k', { famc: ['FK'], fams: ['FK2'] });
  d.individuals.gk = ind('gk', { famc: ['FK2'], fams: ['FK3'] });
  d.individuals.ggk = ind('ggk', { famc: ['FK3'] });
  d.families.FP = fam('FP', 'p', null, ['t', 'sib']);
  d.families.FG = fam('FG', 'gp', null, ['p']);
  d.families.FGG = fam('FGG', 'ggp', null, ['gp']);
  d.families.FK = fam('FK', 't', null, ['k']);
  d.families.FK2 = fam('FK2', 'k', null, ['gk']);
  d.families.FK3 = fam('FK3', 'gk', null, ['ggk']);
  return d;
}
const URL_ = n => `https://www.wikitree.com/wiki/Person-${n}`;

for (const [who, n, label] of [
  ['gp', 101, 'grandparent'], ['ggp', 102, 'great-grandparent'],
  ['gk', 103, 'grandchild'], ['ggk', 104, 'great-grandchild']
]) {
  const d = sibFamily(true);
  d.individuals[who].links = wikiLink(n);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(n),
    `a ${label} with a link beats a sibling with a link`);
}

{
  const d = sibFamily(true);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(100),
    'a sibling is used when nobody in the direct line has a link');
}

// Nearer direct-line generation wins over a farther one.
{
  const d = sibFamily(true);
  d.individuals.gp.links = wikiLink(110);
  d.individuals.ggp.links = wikiLink(111);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(110), 'grandparent beats great-grandparent');
}
{
  const d = sibFamily(true);
  d.individuals.p.links = wikiLink(112);
  d.individuals.gk.links = wikiLink(113);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(112), 'parent (gap 1) beats grandchild (gap 2)');
}
{
  const d = sibFamily(true);
  d.individuals.k.links = wikiLink(114);
  d.individuals.gp.links = wikiLink(115);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(114), 'child (gap 1) beats grandparent (gap 2)');
}
// Same gap: descendant checked ahead of ancestor.
{
  const d = sibFamily(true);
  d.individuals.gp.links = wikiLink(116);
  d.individuals.gk.links = wikiLink(117);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(117), 'at the same gap a grandchild is checked ahead of a grandparent');
}

// Cross-file: a direct-line relative found only in File B still beats a File A sibling.
{
  const dataA = emptyData();
  dataA.individuals.t = ind('t', { famc: ['FP'] });
  dataA.individuals.sib = ind('sib', { famc: ['FP'], links: wikiLink(120) });
  dataA.individuals.p = ind('p', { fams: ['FP'] });
  dataA.families.FP = fam('FP', 'p', null, ['t', 'sib']);
  const dataB = emptyData();
  dataB.individuals.tb = ind('tb', { famc: ['GP'] });
  dataB.individuals.pb = ind('pb', { famc: ['GG'], fams: ['GP'] });
  dataB.individuals.gpb = ind('gpb', { links: wikiLink(121) });
  dataB.families.GP = fam('GP', 'pb', null, ['tb']);
  dataB.families.GG = fam('GG', 'gpb', null, ['pb']);
  check(findNearestWikiTreeUrl(dataA, dataB, 't', 'tb'), URL_(121),
    "a File B grandparent beats a File A sibling");
}

// Spouse ranks below a parent/child but above a grandparent/grandchild and above siblings.
{
  const d = emptyData();
  d.individuals.t = ind('t', { famc: ['FP'], fams: ['FS'] });
  d.individuals.spouse = ind('spouse', { links: wikiLink(130) });
  d.individuals.p = ind('p', { famc: ['FG'], fams: ['FP'] });
  d.individuals.gp = ind('gp', { links: wikiLink(131) });
  d.individuals.sib = ind('sib', { famc: ['FP'], links: wikiLink(133) });
  d.families.FS = fam('FS', 't', 'spouse', []);
  d.families.FP = fam('FP', 'p', null, ['t', 'sib']);
  d.families.FG = fam('FG', 'gp', null, ['p']);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(130), 'a spouse beats a grandparent (and a sibling)');
  d.individuals.p.links = wikiLink(132);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(132), 'but a parent beats a spouse');
}
{
  const d = emptyData();
  d.individuals.t = ind('t', { fams: ['FS', 'FK'] });
  d.individuals.spouse = ind('spouse', { links: wikiLink(134) });
  d.individuals.k = ind('k', { famc: ['FK'], links: wikiLink(135) });
  d.families.FS = fam('FS', 't', 'spouse', []);
  d.families.FK = fam('FK', 't', null, ['k']);
  check(findNearestWikiTreeUrl(d, emptyData(), 't', null), URL_(135), 'a child beats a spouse');
}
{
  const d = emptyData();
  d.individuals.t = ind('t', { fams: ['FS'] });
  d.individuals.spouse = ind('spouse', { links: wikiLink(136) });
  d.families.FS = fam('FS', 't', 'spouse', []);
  const dataB = emptyData();
  dataB.individuals.tb = ind('tb', { famc: ['GG'] });
  dataB.individuals.pb = ind('pb', { famc: ['GH'], fams: ['GG'] });
  dataB.individuals.gpb = ind('gpb', { links: wikiLink(137) });
  dataB.families.GG = fam('GG', 'pb', null, ['tb']);
  dataB.families.GH = fam('GH', 'gpb', null, ['pb']);
  check(findNearestWikiTreeUrl(d, dataB, 't', 'tb'), URL_(136), 'a File A spouse beats a File B grandparent');
}

process.exit(summary('wikitree-fallback'));
