// v50: the descendant walk must drill down as far as the chosen depth on every
// branch, include every descendant's spouse (with marriage details), walk
// THROUGH people already shown as an ancestor's sibling, match children across
// the two files before de-duplicating, and never loop on cyclic data.
const { loadApp, check, summary } = require('../harness');

function rowsOf(app, label) {
  return app.getVar('lastSections').find(s => s.label === label).rows;
}
function allRows(app) {
  return app.getVar('lastSections').flatMap(s => s.rows.map(r => Object.assign({ section: s.label }, r)));
}
const desc = (r) => `${r.role}:${r.status}:${r.name}`;

// (The dropdown options themselves - 0-9 plus All - are covered by generation-options.test.js.)

// ---------- 1. Depth: well past the old cap of 6, and stops at exactly N ----------
function chain(p, n) {
  let out = `0 @${p}R@ INDI\n1 NAME Root /Person/\n1 FAMS @${p}F0@\n0 @${p}F0@ FAM\n1 HUSB @${p}R@\n1 CHIL @${p}K1@\n`;
  for (let i = 1; i <= n; i++) {
    out += `0 @${p}K${i}@ INDI\n1 NAME K${i} /Person/\n1 FAMC @${p}F${i - 1}@\n` + (i < n ? `1 FAMS @${p}F${i}@\n` : '');
    if (i < n) out += `0 @${p}F${i}@ FAM\n1 HUSB @${p}K${i}@\n1 CHIL @${p}K${i + 1}@\n`;
  }
  return out;
}
{
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '1', descendantGen: '12', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(chain('I', 10), chain('P', 10));
  app.runCompare();
  const names = rowsOf(app, 'Root').map(r => r.name);
  check(names.filter(n => /^K\d+ /.test(n)).length, 10, 'depth 12 walks a 10-deep chain completely (old cap was 6)');
  const k10 = rowsOf(app, 'Root').find(r => r.name === 'K10 Person');
  check(k10.role, app.descendantLabel(10), 'the 10th generation is labelled correctly');
  check(k10.distance, 10, 'and its distance from root is 10');
}
{
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '1', descendantGen: '7', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(chain('I', 10), chain('P', 10));
  app.runCompare();
  const names = rowsOf(app, 'Root').map(r => r.name);
  check(names.includes('K7 Person') && !names.includes('K8 Person'), true, 'depth 7 stops after exactly 7 generations');
}

// ---------- 2. Descendants' spouses, with marriage details ----------
{
  const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMS @F0@
0 @F0@ FAM
1 HUSB @I1@
1 CHIL @I2@
0 @I2@ INDI
1 NAME Kid /Person/
1 FAMC @F0@
1 FAMS @F1@
0 @I3@ INDI
1 NAME Kidswife /Person/
1 SEX F
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I3@
1 MARR
2 DATE 1 JAN 1950
2 PLAC Leeds
1 CHIL @I4@
0 @I4@ INDI
1 NAME Grandkid /Person/
1 FAMC @F1@
1 FAMS @F2@
0 @I5@ INDI
1 NAME Grandkidshusband /Person/
1 SEX M
1 FAMS @F2@
0 @F2@ FAM
1 HUSB @I5@
1 WIFE @I4@
1 CHIL @I6@
0 @I6@ INDI
1 NAME Greatgrandkid /Person/
1 FAMC @F2@
`;
  const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMS @G0@
0 @G0@ FAM
1 HUSB @P1@
1 CHIL @P2@
0 @P2@ INDI
1 NAME Kid /Person/
1 FAMC @G0@
1 FAMS @G1@
0 @P3@ INDI
1 NAME Kidswife /Person/
1 SEX F
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P2@
1 WIFE @P3@
1 MARR
2 DATE 2 JAN 1950
2 PLAC Leeds
1 CHIL @P4@
0 @P4@ INDI
1 NAME Grandkid /Person/
1 FAMC @G1@
`;
  const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', descendantGen: '3', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  const rows = rowsOf(app, 'Root');
  const byName = n => rows.find(r => r.name === n);
  const list = rows.map(desc);

  check(list.includes("Child's spouse:both:Kidswife Person"), true, "a child's spouse is listed and matched across files");
  check(list.includes("Grandchild's spouse:missB:Grandkidshusband Person"), true,
    "a grandchild's spouse present only in File A is reported missing from File B");
  check(list.includes('Great-grandchild:missB:Greatgrandkid Person'), true,
    'and the walk continues below a one-sided descendant\'s spouse (via the family record)');
  const sp = byName('Kidswife Person');
  const mdate = sp.fieldDiffs.find(f => f.label === 'Marriage date');
  check([mdate.a, mdate.b, mdate.same], ['1 JAN 1950', '2 JAN 1950', false],
    'the descendant spouse row carries marriage date (a one-day difference on exact dates is a difference)');
  check(sp.fieldDiffs.find(f => f.label === 'Marriage place').same, true, 'and marriage place');
  check(sp.relationshipTerm, 'Daughter-in-law', "root's child's wife reads Daughter-in-law");
  check(byName('Grandkidshusband Person').relationshipTerm, "Grandchild's husband", "deeper spouses read as \"<term>'s husband\"");
  check([byName('Kid Person').distance, sp.distance, byName('Grandkid Person').distance, byName('Grandkidshusband Person').distance],
    [1, 2, 2, 3], "a descendant's spouse is one step further from root than the descendant");
  // order: person, then their spouse, then the next generation
  const idx = n => list.findIndex(x => x.endsWith(n));
  check(idx('Kid Person') < idx('Kidswife Person') && idx('Kidswife Person') < idx('Grandkid Person'), true,
    'each spouse row sits directly after their partner, before the next generation');
  check(list.filter(x => x.includes('Kidswife')).length, 1, 'each spouse is listed once');

  // helper functions
  check([app.isDescendantSpouseRole("Child's spouse"), app.isDescendantSpouseRole("Great-grandchild's spouse"),
         app.isDescendantSpouseRole("Sibling's spouse"), app.isDescendantSpouseRole('Spouse')],
        [true, true, false, false], 'isDescendantSpouseRole recognises only descendants\' spouses');
  check([app.distanceFromRoot("Child's spouse", 'FF'), app.distanceFromRoot("Grandchild's spouse", '')],
        [3, 3], 'distanceFromRoot: descendant distance + 1 (L=2,d=1 -> 3; L=0,d=2 -> 3)');
}

// ---------- 3. Siblings on: an ancestor sibling's subtree is not a dead end ----------
function uncleTree(p, extra) {
  return `0 @${p}R@ INDI
1 NAME Root /Person/
1 FAMC @${p}F1@
0 @${p}FA@ INDI
1 NAME Father /Person/
1 FAMC @${p}G1@
1 FAMS @${p}F1@
0 @${p}MU@ INDI
1 NAME Mum /Person/
1 FAMS @${p}F1@
0 @${p}GR@ INDI
1 NAME Grandad /Person/
1 FAMS @${p}G1@${extra ? '\n1 FAMS @' + p + 'G3@' : ''}
0 @${p}UN@ INDI
1 NAME Uncle /Person/
1 FAMC @${extra ? p + 'G3' : p + 'G1'}@
1 FAMS @${p}FU@
0 @${p}CO@ INDI
1 NAME Cousin /Person/
1 FAMC @${p}FU@
1 FAMS @${p}FC@
0 @${p}C2@ INDI
1 NAME Cousinskid /Person/
1 FAMC @${p}FC@
0 @${p}F1@ FAM
1 HUSB @${p}FA@
1 WIFE @${p}MU@
1 CHIL @${p}R@
0 @${p}G1@ FAM
1 HUSB @${p}GR@
1 CHIL @${p}FA@${extra ? '' : '\n1 CHIL @' + p + 'UN@'}
${extra ? `0 @${p}G3@ FAM\n1 HUSB @${p}GR@\n1 CHIL @${p}UN@\n` : ''}0 @${p}FU@ FAM
1 HUSB @${p}UN@
1 CHIL @${p}CO@
0 @${p}FC@ FAM
1 HUSB @${p}CO@
1 CHIL @${p}C2@
`;
}
for (const sibs of [true, false]) {
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '2', descendantGen: '3', includeSiblings: sibs, categoryVisibility: { exact: true } });
  app.loadGedcomFiles(uncleTree('I'), uncleTree('P'));
  app.runCompare();
  const all = allRows(app);
  const tag = sibs ? 'siblings ON' : 'siblings OFF';
  const ff = rowsOf(app, "Father's father").map(desc);
  check(all.filter(r => r.name === 'Uncle Person').length, 1, `${tag}: Uncle is listed exactly once in the whole report`);
  check(ff.includes('Grandchild:both:Cousin Person'), true, `${tag}: Uncle's child (Cousin) is reached under the grandparent`);
  check(ff.includes('Great-grandchild:both:Cousinskid Person'), true, `${tag}: ...and Cousin's child, three generations down`);
  check(all.some(r => r.role.endsWith("'s spouse") && r.role !== "Spouse"), false, `${tag}: no phantom descendant-spouse rows where nobody has a spouse`);
  const cousin = rowsOf(app, "Father's father").find(r => r.name === 'Cousin Person');
  check([cousin.relationshipTerm, cousin.distance], ['1st cousin', 3], `${tag}: Cousin reads 1st cousin at distance 3`);
  if (sibs) {
    check(rowsOf(app, 'Father').map(desc).includes('Sibling:both:Uncle Person'), true, 'siblings ON: Uncle appears as a Sibling under Father');
    check(ff.includes('Child:both:Uncle Person'), false, 'siblings ON: ...and is NOT repeated as a Child under the grandparent');
  } else {
    check(ff.includes('Child:both:Uncle Person'), true, 'siblings OFF: Uncle appears as a Child under the grandparent');
  }
}

// ---------- 4. Symmetric coverage: shown on one side must not make the other look missing ----------
{
  // In File B, Uncle is Grandad's child by a DIFFERENT marriage, so he is not Father's
  // sibling there. With siblings on, File A lists him as Sibling (missing from B); the
  // grandparent's walk must then treat the (matched) pair as already shown rather than
  // reporting a second, bogus "missing from File A" Child row for File B's Uncle.
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '2', descendantGen: '1', includeSiblings: true, categoryVisibility: { exact: true } });
  app.loadGedcomFiles(uncleTree('I'), uncleTree('P', true));
  app.runCompare();
  const uncles = allRows(app).filter(r => r.name === 'Uncle Person');
  check(uncles.map(r => `${r.role}:${r.status}`), ['Sibling:missB'],
    'Uncle appears once (as a File A-only Sibling), with no extra bogus "missing from A" Child row');
}

// ---------- 5. Cycles and pedigree collapse can't loop or duplicate ----------
{
  const cyc = p => `0 @${p}R@ INDI
1 NAME Root /Person/
1 FAMS @${p}F0@
0 @${p}F0@ FAM
1 HUSB @${p}R@
1 CHIL @${p}K1@
0 @${p}K1@ INDI
1 NAME K1 /Person/
1 FAMC @${p}F0@
1 FAMC @${p}F3@
1 FAMS @${p}F2@
0 @${p}K2@ INDI
1 NAME K2 /Person/
1 FAMC @${p}F2@
1 FAMS @${p}F3@
1 FAMS @${p}F4@
0 @${p}K3@ INDI
1 NAME K3 /Person/
1 SEX F
1 FAMC @${p}F2@
1 FAMS @${p}F4@
0 @${p}K4@ INDI
1 NAME K4 /Person/
1 FAMC @${p}F4@
0 @${p}F2@ FAM
1 HUSB @${p}K1@
1 CHIL @${p}K2@
1 CHIL @${p}K3@
0 @${p}F3@ FAM
1 HUSB @${p}K2@
1 CHIL @${p}K1@
0 @${p}F4@ FAM
1 HUSB @${p}K2@
1 WIFE @${p}K3@
1 CHIL @${p}K4@
`;
  const app = loadApp({ rootA: 'IR', rootB: 'PR', maxGen: '1', descendantGen: '12', categoryVisibility: { exact: true } });
  app.loadGedcomFiles(cyc('I'), cyc('P'));
  app.runCompare();   // would hang / overflow the stack without the visited-set
  // K3 is both K1's child and (by design of this fixture) K2's wife, so she may be
  // listed as either; what matters is that she appears exactly once in total.
  const names = rowsOf(app, 'Root').map(r => r.name);
  for (const n of ['K1 Person', 'K2 Person', 'K3 Person', 'K4 Person']) {
    check(names.filter(x => x === n).length, 1, `cyclic / pedigree-collapse data: ${n} is listed exactly once`);
  }
}

process.exit(summary('descendant-drilldown'));
