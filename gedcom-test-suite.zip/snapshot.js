// Golden-snapshot tool for ZERO-BEHAVIOUR-CHANGE refactors.
//   node snapshot.js > before.txt      (run on the CURRENT html)
//   ...make the change...
//   node snapshot.js > after.txt ; diff before.txt after.txt   (must be empty)
// Renders the report for many compare + display settings combinations on a rich
// synthetic GEDCOM pair and prints one md5 per combination. Needs harness.js and
// gen-fixture.js in the same folder, and GEDCOMparator.html next to harness.js.
const crypto = require('crypto');
const { loadApp } = require('./harness');
const { buildTree, toGedcom, MUTATION } = require('./gen-fixture');

const tree = buildTree(4, 7);
const gedA = toGedcom(tree, null, 1);
const gedB = toGedcom(tree, MUTATION, 2);
const md5 = s => crypto.createHash('md5').update(s).digest('hex').slice(0, 12);

const compareCombos = [
  { maxGen: '4', includeSiblings: false, includeAncestorSpouses: true, descendantGen: '0' },
  { maxGen: '4', includeSiblings: true, includeSibSpouses: true, includeAncestorSpouses: true, descendantGen: '0' },
  { maxGen: '3', includeSiblings: true, includeAncestorSpouses: true, descendantGen: '3' },
  { maxGen: 'all', includeSiblings: true, includeSibSpouses: true, includeAncestorSpouses: false, descendantGen: 'all' },
];
const displayCombos = [
  { label: 'default-flat', set: {} },
  { label: 'grouped', set: { groupByAncestor: true } },
  { label: 'grouped-expanded-all-cats', set: { groupByAncestor: true, hideAllSubDetails: false }, cats: { exact: true, similar: true } },
  { label: 'flat-all-cats-noalivefilter', set: { ignoreLikelyAlive: false }, cats: { exact: true, similar: true } },
  { label: 'hide-nodob-grouped', set: { groupByAncestor: true, hideNoBirthDate: true }, cats: { exact: true, similar: true } },
  { label: 'father-side-dist3', set: { sideFilter: 'father', generationLimit: '3' }, cats: { exact: true } },
  { label: 'surname', set: { surnameFilter: 'Smi*, Jones' }, cats: { exact: true, similar: true } },
  { label: 'loose-tolerances', set: { nameTolerance: '30', dateTolerance: '365', locationTolerance: '90' }, cats: { exact: true, similar: true } },
  { label: 'strict-tolerances', set: { nameTolerance: '0', dateTolerance: '0', locationTolerance: '0', groupByAncestor: true }, cats: { exact: true, similar: true } },
  { label: 'only-missing', set: {}, cats: { exact: false, similar: false, diffs: false, substantial: false, missing: true } },
];

const lines = [];
compareCombos.forEach((cc, ci) => {
  displayCombos.forEach(dc => {
    const app = loadApp(Object.assign({ rootA: 'I1', rootB: 'I1', generationLimit: 'all' }, cc, dc.set, dc.cats ? { categoryVisibility: dc.cats } : {}));
    app.loadGedcomFiles(gedA, gedB);
    app.runCompare();
    const html = app._document._el('report').innerHTML;
    lines.push(`compare#${ci} / ${dc.label}: ${md5(html)} (${html.length} chars)`);
  });
});
console.log(lines.join('\n'));
console.log('ALL: ' + md5(lines.join('\n')));
