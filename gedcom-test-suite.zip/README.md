# GEDCOM Tree Comparator — Test Suite

Unit tests for the logic behind `GEDCOMparator.html` — the GEDCOM parser, WWW
link classification and the "Nearest WikiTree" fallback, ancestor/sibling/
spouse/descendant matching and de-duplication, the relationship-to-root
calculator, the genealogy-aware date-exactness rules, the "substantially
different" red/amber/green header logic, and every report-control filter
(the five per-category summary-card tickboxes, hide people likely still
alive, hide people with no birth date, treat similar locations as matching,
hide reviewed items, group by ancestor vs. show every individual separately,
and the collapse/expand controls). These run in plain Node.js — no browser
needed — by loading the app's inline `<script>` into a small sandboxed `vm`
context with a stubbed-out `document` object.

## Setup

Place `GEDCOMparator.html` in the **same folder** as `harness.js` and
`run-tests.js`, i.e.:

```
your-folder/
  GEDCOMparator.html
  harness.js
  run-tests.js
  tests/
    ambiguous-name-matching.test.js
    category-toggles.test.js
    date-matching.test.js
    descendant-generations.test.js
    descendant-labels.test.js
    display-mode.test.js
    gedcom-parsing-and-links.test.js
    marriage-and-rendering.test.js
    matching-and-toggles.test.js
    place-similarity.test.js
    relationship-terms.test.js
    root-selection.test.js
    section-collapse.test.js
    section-status.test.js
    substantial-difference.test.js
    tolerance-settings.test.js
    wikitree-fallback.test.js
```

`harness.js` reads `GEDCOMparator.html` directly at test-run time (it extracts
the inline `<script>` block itself — there's no separate pre-generated
`app.js` to keep in sync, so editing the HTML is immediately reflected the
next time you run the tests).

## Running the tests

Run everything:

```
node run-tests.js
```

Or run a single test file directly:

```
node tests/date-matching.test.js
```

Each test file prints a `PASS`/`FAIL` line per case and a summary count, and
exits with a non-zero status code if anything failed (so it's CI-friendly if
you ever want to hook it into something).

## What's covered

- **gedcom-parsing-and-links.test.js** — the GEDCOM parser: name parsing
  (given/surname/suffix), CONC (no separator) vs. CONT (newline)
  continuation, multiple FAMS tags, xref stripping, level-0 records that
  aren't INDI/FAM (HEAD, TRLR), and WWW-tag link classification (recognized
  genealogy domains, bare domains, non-http(s) schemes, unparseable URLs).
- **matching-and-toggles.test.js** — `matchLists`' two matching passes
  (exact name, then birth-year-only fallback when names don't match at all),
  and the three independent "include spouses of ancestors" / "include
  siblings of ancestors" / "include spouses of siblings" toggles (including
  the UI guard that disables/forces off sibling-spouses when siblings is
  unchecked).
- **ambiguous-name-matching.test.js** — when two individuals in one file
  share a name and birth year alone doesn't disambiguate them, the matcher
  tries death year next, and only ever offers a still-tied pair at "maybe"
  confidence rather than silently guessing.
- **date-matching.test.js** — the date exactness hierarchy: Exact > About >
  Year > Bef/Aft, month-name normalization (Nov/November), the adjustable
  "Date tolerance" window for approximate dates (fixed at 91 days/~3 months
  by default), the rule that Bef/Aft dates only match an identical
  qualifier + date, and the tightening where an EXACT date on *either* side
  of a comparison gets zero tolerance regardless of the setting (not just
  when both sides are exact).
- **ancestor-dedup** (see `descendant-generations.test.js`, which also
  covers this) — confirms a direct ancestor is never repeated elsewhere in
  the report.
- **descendant-generations.test.js** — the "children of ancestors" option
  surfaces genuinely new people while staying out of scope for collateral
  relatives (a sibling's child).
- **descendant-labels.test.js** — generation labels through several levels:
  Child → Grandchild → Great-grandchild → Great-great-grandchild.
- **relationship-terms.test.js** — the full relationship-to-root calculator:
  parents/grandparents/great-grandparents, children/grandchildren, siblings
  (full and the documented half-sibling approximation), aunts/uncles,
  nieces/nephews, Nth cousins (including "removed"), step-relations for an
  ancestor's spouse, and the higher-level `relationshipInfo()` wrapper's
  path descriptions.
- **wikitree-fallback.test.js** — the "Nearest WikiTree" breadth-first
  search: children and parents (blood, one step away) always checked ahead
  of a spouse found at the same depth, each step outward explored only once
  the previous step is exhausted (siblings and grandparents at 2 steps,
  in-laws via a spouse's own parent, etc. — relations the old fixed
  relationship-type list could never reach at all), checked across both
  files before going deeper, plus the cross-file counterpart fallback and
  its own refusal to guess at an ambiguous name collision.
- **place-similarity.test.js** — the Sørensen-Dice bigram similarity used
  by "Location tolerance".
- **substantial-difference.test.js** — the red/green "substantially
  different" header flag: name differences beyond the adjustable "Name
  tolerance" edit-distance threshold (fixed at 2 characters by default,
  ignoring extra/missing/reordered middle names), birth-year gaps over 10
  years, unrelated birth places, the subset/superset location exception
  (e.g. "Torgau, Germany" vs. "Germany"), and that a blank field on one side
  is never treated as a conflict.
- **tolerance-settings.test.js** — the "Similarity settings" panel:
  `datesMatch`'s adjustable `toleranceDays` parameter (wider tolerance widens
  the approximate-date match window; an EXACT date on either side is never
  widened, however large the setting); `isMinorSpellingVariant`'s adjustable
  `maxDistance` parameter feeding `nameSubstantiallyDifferent`; an end-to-end
  `runCompare()` check that Name tolerance is read once at compare time
  (unlike Location/Date tolerance, it doesn't retroactively change an
  already-generated report); that a 0% Location tolerance behaves exactly
  like the old "hide matches with similar locations" checkbox being
  unchecked; and — as of v40 — that Date tolerance is live: widening the
  slider after `runCompare()`, with only `renderReport()` called again (no
  re-compare), changes a rendered date field from a real diff to "dates
  recognized as equivalent".
- **section-status.test.js** — the five-way exact/similar/amber/missing/red
  ancestor-section header status computed over every row in a section
  (a brighter red reserved exclusively for a substantial difference; a
  distinct, deeper red — "missing" — for anything missing from either
  file; the "similar" vs. "exact" split for a clean match, via
  `matchExactness()` — a leniency-recognized date or a similarity-matched
  location keeps a match "similar" rather than "exact"; ranked worst to
  best: red > missing > amber > similar > exact), and how it's excused by
  Location tolerance, "hide people likely still alive", "hide people with no
  date of birth", and being individually marked Reviewed.
- **coloring-scheme.test.js** — an end-to-end check (real
  `runCompare()`/`renderReport()` pass, plus the CSS source itself) that
  missing from either file always renders with the same deep-red badge/
  section class ("missing"), that this is a genuinely different colour
  (different hex value) from the brighter red reserved exclusively for a
  substantially-different match even when a section has both, and that a
  genuinely exact match renders the deeper-green "Exact match" badge/
  header while a leniency-only match keeps the original lighter green.
- **summary-cards.test.js** — the 5-box summary layout, one card per
  status colour (exact, similar, needs verification/amber, substantial
  difference/red, missing/deep-red) in worst-to-best order, replacing the
  separate colour-key legend entirely; the merged "Missing from either
  file" card with the File A/File B split moved into small print beneath
  the combined number.
- **section-collapse.test.js** — the collapse/expand chevron on each
  section, default-collapsed behavior, and the "Hide all sub-details" master
  checkbox.
- **display-mode.test.js** — "Group results by ancestor" vs. showing every
  individual as their own section (no nested match-card), confirming nobody
  is ever listed twice and that summary counts don't change with the display
  mode.
- **category-toggles.test.js** — the five per-category summary-card
  tickboxes (exact, similar, needs verification, substantial difference,
  missing) that replaced the old "Hide exact matches" / "Hide all matches,
  show only missing people" / "Only show items needing attention"
  checkboxes: unticking a card hides only that category's rows, in both
  display modes, without changing any summary count; a fresh app still
  starts with exact matches hidden and everything else shown, matching the
  old default; and the hidden-count legend names the right category.
- **side-filter.test.js** — the "Father's side / Both sides / Mother's
  side" filter: scoping entire ancestor sections by which parent-link their
  lineage code starts with, the root's own section always staying visible
  regardless of the filter, working the same way in both display modes, and
  actually reducing the summary counts (unlike the purely cosmetic
  decluttering filters).
- **reviewed-persistence.test.js** — "Reviewed" marks surviving closing and
  reopening the page: round-tripping through localStorage (simulated by two
  separate `loadApp()` calls sharing the same backing store), scoped per
  pair-of-files so a different pair never sees another's marks, keyed per-
  person so the mark survives even when a changed setting reshuffles row
  ids, un-reviewing persisting the removal, and "Clear saved review marks"
  wiping both the in-memory and stored state.
- **scroll-behavior.test.js** — the report auto-scrolls into view exactly
  once, the first time it appears after "Compare trees", and never again on
  a subsequent re-render (ticking Reviewed, an ordinary filter checkbox,
  switching display mode, "Hide all sub-details") — but does scroll again
  after a genuinely fresh comparison.
- **marriage-and-rendering.test.js** — the extra Marriage date/place
  comparison rows added for a matched spouse pair, `renderValueCell`'s
  "dates recognized as equivalent" and "similar in both" annotations,
  `matchYearsSuffix`'s "(DoB-DoD)" formatting, and HTML-escaping safety for
  names containing markup-significant characters.
- **root-selection.test.js** — auto-matching a shared root name across both
  files, the root-person dropdown's filtering, and the one-way mirroring
  between the two filter boxes (File A's typing live-updates File B's, until
  the person edits File B's box directly).

## Adding a new test

Add a new `tests/*.test.js` file following the same pattern (`require('../harness')`,
build a small GEDCOM fixture — or, for functions that operate on already-parsed
data (`matchLists`, `findNearestWikiTreeUrl`, `relationshipFromUV`, ...), a
small hand-built data object is often simpler than a full GEDCOM fixture — call
`loadApp()`, run whichever function(s) you need, and `check()` the results).
`run-tests.js` picks up any file automatically — no need to register it
anywhere.

## How the harness works

`harness.js` runs the HTML's inline `<script>` inside a Node `vm` context
with a minimal stubbed `document` (just enough `getElementById(id).value` /
`.checked` / `.style` / `.innerHTML` / `.classList` plumbing for the app to
run its normal `runCompare()` / `renderReport()` flow without a real
browser). `loadApp(overrides)` seeds every checkbox/input to match the real
HTML's actual default `checked`/`value` attributes (so a test reflects true
default behavior unless it explicitly overrides a setting), then extracts
every top-level `function` from the script (`parseGedcom`, `datesMatch`,
`matchLists`, `relationshipFromUV`, `runCompare`, ...) onto the returned
`app` object, so tests can call them directly — e.g. `const { datesMatch } =
app;` or `app.runCompare()`.

Two things are worth knowing if you're extending the harness:

- Top-level `function` declarations become properties on the sandbox
  automatically, and `loadApp()` bridges all of them onto the returned `app`
  object.
- Top-level `let`/`const` state (`dataA`, `dataB`, `lastSections`,
  `collapsedSections`, `reviewedIds`, `categoryVisibility`, ...) does **not**
  become a sandbox property — that's normal JS lexical scoping, not a bug —
  but it stays live across separate `vm.runInContext` calls on the same
  context.
  `app.getVar('lastSections')` and `app.loadGedcomFiles(gedA, gedB)` both
  rely on this to read and write that state from outside the sandbox. If you
  need to mutate other top-level state directly in a test (as
  `section-collapse.test.js` and `section-status.test.js` do with
  `collapsedSections` and `reviewedIds`), use `app.getVar('someVar')` to read
  the live object (Sets/Maps can then be mutated in place) — there's
  currently no `setVar` helper since every existing test only ever needed to
  mutate an object already returned by `getVar`, not replace it outright.
  `categoryVisibility` is the one exception with dedicated support: pass a
  `categoryVisibility: {...}` override to `loadApp()` and the harness applies
  it via `Object.assign` right after the script loads (see harness.js), since
  it isn't a checkbox in the DOM the way the other settings are — its five
  tickboxes live inside the report's own re-rendered innerHTML instead (see
  `category-toggles.test.js`).
