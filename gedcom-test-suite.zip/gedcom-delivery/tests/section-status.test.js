// Tests computeSectionStatus() — the ancestor section header's colour,
// computed over every row under that ancestor, ranked worst to best:
//  - red: a substantially-different matched pair — and ONLY that; a missing
//         person is never red
//  - missing: a missing person (from either file), a deep red distinct
//            from the substantial-difference red, when nothing is red
//  - amber: an unresolved "maybe" match, or a routine (non-substantial) diff,
//           when nothing is red or missing
//  - similar: a clean match that only counts as matching thanks to a
//             leniency setting (see matchExactness()) — the lighter green
//  - exact: a genuinely exact clean match, or excused by settings/review —
//           the deeper green, and the best possible status
const { loadApp, check, summary } = require('../harness');

function section(rows) { return { rows }; }
function row(overrides) {
  return Object.assign({ id: row._id = (row._id || 0) + 1, status: 'both', fieldDiffs: [], substantiallyDifferent: false, birthDate: '1900' }, overrides);
}

const app = loadApp();
const { computeSectionStatus, matchExactness } = app;
const IGNORE_ALIVE = true, ALIVE_YEARS = 80, HIDE_NO_DOB = false, IGNORE_SIM_LOC = true, LOC_THRESH = 0.5;
const call = (rows) => computeSectionStatus(section(rows), IGNORE_ALIVE, ALIVE_YEARS, HIDE_NO_DOB, IGNORE_SIM_LOC, LOC_THRESH);

// --- exact cases ---
check(call([row({ status: 'both', fieldDiffs: [{ same: true, type: 'text', a: 'Smith', b: 'Smith' }] })]), 'exact',
  'a single clean matched row with literally identical field text is exact');
check(call([
  row({ status: 'both', fieldDiffs: [{ same: true, type: 'text', a: 'Smith', b: 'Smith' }] }),
  row({ status: 'missB', birthDate: '2015' }) // a very recent birth, no death — likely still alive, excused
]), 'exact',
  'a missing person excused by "hide people likely still alive" does not turn the header the deep "missing" red, leaving it exact');
check(call([
  row({ id: 99, status: 'both', fieldDiffs: [{ same: false, type: 'text' }] })
]), 'amber',
  'sanity: an actual unresolved diff (not reviewed) is NOT exact — confirms the excusal above is doing real work');
check(call([row({ status: 'both', fieldDiffs: [] })]), 'exact', 'a matched row with no compared fields at all defaults to exact');

// --- similar cases: a clean match only via a leniency setting ---
check(call([
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'place', similarity: 0.6, a: 'Springfield, IL', b: 'Springfield, Illinois' }] })
]), 'similar',
  'a location difference that similarity-matching would hide is a clean match, but only "similar" — the lighter green, not "exact"');
check(call([
  row({ status: 'both', fieldDiffs: [{ same: true, type: 'date', a: '12 Nov 1900', b: '12 November 1900' }] })
]), 'similar',
  'a date recognized as equivalent despite different wording is "similar", not "exact"');
check(call([
  row({ status: 'both', fieldDiffs: [
    { same: true, type: 'text', a: 'Smith', b: 'Smith' },
    { same: true, type: 'date', a: '1900', b: '1900' }
  ] })
]), 'exact',
  'identical text and an identically-worded date together are still exact');
check(call([
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'place', similarity: 0.6, a: 'A', b: 'B' }] }),
  row({ status: 'both', fieldDiffs: [{ same: true, type: 'text', a: 'X', b: 'X' }] })
]), 'similar',
  'similar outranks exact when both are present in the same section');

// --- amber outranks similar ---
check(call([
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'place', similarity: 0.6, a: 'A', b: 'B' }] }), // similar
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'text' }] }) // amber
]), 'amber', 'amber outranks similar when both are present in the same section');

// --- "missing" cases: a deep red, distinct from the brighter substantial-difference red ---
check(call([row({ status: 'missA' })]), 'missing', 'a missing person (not excused) gets the deep-red "missing" status, not the brighter substantial-difference red');
check(call([row({ status: 'missB' })]), 'missing', 'missing from File B is also the same deep red — colour no longer distinguishes A from B');
check(call([
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'text' }] }), // amber
  row({ status: 'missA' }) // missing
]), 'missing', '"missing" outranks amber when both are present in the same section');

// --- red cases: reserved exclusively for a substantially-different match ---
check(call([row({ status: 'both', substantiallyDifferent: true, fieldDiffs: [{ same: false, type: 'text' }] })]), 'red',
  'a substantially-different matched row is red');
check(call([
  row({ status: 'both', substantiallyDifferent: true }),
  row({ status: 'both', fieldDiffs: [{ same: false, type: 'text' }] }) // amber
]), 'red',
  'red outranks amber when both are present in the same section');
check(call([
  row({ status: 'both', substantiallyDifferent: true }), // red
  row({ status: 'missA' }) // missing
]), 'red',
  'red outranks "missing" too — a confirmed substantial difference is the single worst status, even alongside a missing person');

// --- reviewed rows are always excused, whatever their status ---
{
  const reviewedRow = row({ id: 555, status: 'missA', aId: null, bId: 'p555' });
  app.getVar('reviewedIds').add(app.personKey(reviewedRow));
  check(call([reviewedRow]), 'exact', 'a reviewed missing-person row does not turn the header the deep "missing" red');
  const reviewedDiff = row({ id: 556, status: 'both', substantiallyDifferent: true, aId: 'a556', bId: 'b556' });
  app.getVar('reviewedIds').add(app.personKey(reviewedDiff));
  check(call([reviewedDiff]), 'exact', 'a reviewed substantially-different row does not turn the header red');
}

// --- hideNoBirthDate excusal ---
check(computeSectionStatus(
  section([row({ status: 'both', birthDate: '', fieldDiffs: [{ same: false, type: 'text' }] })]),
  IGNORE_ALIVE, ALIVE_YEARS, /* hideNoBirthDate */ true, IGNORE_SIM_LOC, LOC_THRESH
), 'exact', 'a diff on a person with no birth date is excused when "hide people with no date of birth" is on');

// --- matchExactness() directly ---
check(matchExactness(row({ fieldDiffs: [{ same: true, type: 'text', a: 'Smith', b: 'Smith' }] })), 'exact',
  'matchExactness: identical text is exact');
check(matchExactness(row({ fieldDiffs: [] })), 'exact', 'matchExactness: no fields to compare defaults to exact');
check(matchExactness(row({ fieldDiffs: [{ same: true, type: 'date', a: '1 Jan 1900', b: '01 January 1900' }] })), 'similar',
  'matchExactness: a date match with different wording is similar');
check(matchExactness(row({ fieldDiffs: [{ same: true, type: 'date', a: '1900', b: '1900' }] })), 'exact',
  'matchExactness: a date match with IDENTICAL wording is exact, not similar');
check(matchExactness(row({ fieldDiffs: [{ same: false, type: 'place', similarity: 0.9, a: 'X', b: 'Y' }] }), true, 0.5), 'similar',
  'matchExactness: a place waved through by the similarity threshold is similar');
check(matchExactness(row({ fieldDiffs: [{ same: false, type: 'place', similarity: 0.9, a: 'X', b: 'Y' }] }), false, 0.5), 'exact',
  'matchExactness: the same place difference is exact when "treat similar locations as matching" is off — rowHasEffectiveDiff would already have excluded this row from being clean at all in that case, but matchExactness itself is defensive either way');

process.exit(summary('section-status'));
