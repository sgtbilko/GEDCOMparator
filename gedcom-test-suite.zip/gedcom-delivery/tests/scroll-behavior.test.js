// Tests that the report scrolls into view exactly once after a fresh
// "Compare trees" click, and NOT again on every subsequent re-render — ticking
// Reviewed, toggling a filter checkbox, changing a slider, switching display
// mode, etc. all call renderReport() directly and used to re-trigger
// scrollIntoView() every single time, yanking the page back to the top of
// the report and discarding wherever the person had scrolled to.
const { loadApp, check, summary } = require('../harness');

const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMS @F1@
0 @I2@ INDI
1 NAME Spouse /Person/
1 FAMS @F1@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
`;
const gedB = gedA.replace(/@I(\d)@/g, '@P$1@').replace(/@F1@/g, '@G1@');

const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } });
app.loadGedcomFiles(gedA, gedB);

function scrollCalls() {
  return app._document.getElementById('report')._scrollIntoViewCalls || 0;
}

// --- First compare: scrolls exactly once ---
app.runCompare();
check(scrollCalls(), 1, 'the first render after "Compare trees" scrolls the report into view once');

// --- Ticking Reviewed re-renders but must NOT scroll again ---
const rootSection = app.getVar('lastSections').find(s => s.label === 'Root');
const rootRow = rootSection.ancestorHeader;
app.toggleReviewed(app.personKey(rootRow), true);
check(scrollCalls(), 1, 'ticking a Reviewed checkbox re-renders the report but does not scroll again');
app.toggleReviewed(app.personKey(rootRow), false);
check(scrollCalls(), 1, 'un-ticking it likewise does not scroll');

// --- Toggling an ordinary filter checkbox must not scroll either ---
app.onCategoryToggle('exact', false);
check(scrollCalls(), 1, 'toggling a category-visibility tickbox does not scroll');

// --- Switching display mode and the master collapse checkbox: no scroll ---
app._document.getElementById('groupByAncestor').checked = false;
app.onGroupByAncestorChange();
check(scrollCalls(), 1, 'switching to flat display mode does not scroll');
app._document.getElementById('hideAllSubDetails').checked = false;
app.onHideAllSubDetailsChange();
check(scrollCalls(), 1, '"Hide all sub-details" does not scroll');

// --- A fresh comparison DOES scroll again — the guard resets, it isn't a
// permanent one-time-ever flag ---
app.runCompare();
check(scrollCalls(), 2, 'running a fresh comparison scrolls into view again, exactly once');
app.onFilterChange();
check(scrollCalls(), 2, 'and again, a subsequent re-render after that fresh compare does not scroll further');

process.exit(summary('scroll-behavior'));
