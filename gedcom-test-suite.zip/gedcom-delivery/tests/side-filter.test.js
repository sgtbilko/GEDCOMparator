// Tests the "Father's side" / "Both sides" / "Mother's side" filter: it
// scopes entire ancestor sections (and, in flat mode, every row belonging to
// one) by which parent-link a lineage code starts with, while always keeping
// the root's own section (siblings/spouse/children of the root person) shown
// regardless of the filter — the root isn't part of either parent's side.
const { loadApp, check, summary } = require('../harness');

// Root, Father (F) with his own sibling (Uncle), Mother (M) with her own
// sibling (Aunt), each with the OTHER file's individual having a
// substantial name difference so nothing gets hidden by "hide exact
// matches" while we're checking scope.
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Mum /Person/
1 FAMS @F1@
1 FAMC @F3@
0 @I4@ INDI
1 NAME Uncle /Person/
1 FAMC @F2@
0 @I5@ INDI
1 NAME Aunt /Person/
1 FAMC @F3@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I3@
1 CHIL @I1@
0 @F2@ FAM
1 CHIL @I2@
1 CHIL @I4@
0 @F3@ FAM
1 CHIL @I3@
1 CHIL @I5@
`;
const gedB = gedA.replace(/@I(\d)@/g, '@P$1@').replace(/@F(\w*)@/g, '@G$1@');

const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, hideExactMatches: false });
app.loadGedcomFiles(gedA, gedB);
app.runCompare();

function sectionCodesShown() {
  const html = app._document.getElementById('report').innerHTML;
  return {
    root: html.includes('>Root Person<'),
    dad: html.includes('>Dad Person<'),
    mum: html.includes('>Mum Person<'),
    uncle: html.includes('Uncle Person'),
    aunt: html.includes('Aunt Person'),
  };
}

// --- default: "both" shows everything ---
check(app._document.getElementById('sideFilter').value, 'both', 'the filter defaults to "both"');
let shown = sectionCodesShown();
check(shown, { root: true, dad: true, mum: true, uncle: true, aunt: true }, '"Both sides" (default) shows the whole tree');

// --- Father's side: Father + his own sibling, never Mother's line ---
app._document.getElementById('sideFilter').value = 'father';
app.onFilterChange();
shown = sectionCodesShown();
check(shown, { root: true, dad: true, mum: false, uncle: true, aunt: false },
  '"Father\'s side" keeps Root and the paternal line (Dad, Uncle), hides the maternal line (Mum, Aunt)');

// --- Mother's side: the mirror image ---
app._document.getElementById('sideFilter').value = 'mother';
app.onFilterChange();
shown = sectionCodesShown();
check(shown, { root: true, dad: false, mum: true, uncle: false, aunt: true },
  '"Mother\'s side" keeps Root and the maternal line (Mum, Aunt), hides the paternal line (Dad, Uncle)');

// --- Back to both ---
app._document.getElementById('sideFilter').value = 'both';
app.onFilterChange();
check(sectionCodesShown(), { root: true, dad: true, mum: true, uncle: true, aunt: true }, 'switching back to "Both sides" restores everything');

// --- Works the same way in flat (ungrouped) mode ---
app._document.getElementById('groupByAncestor').checked = false;
app._document.getElementById('sideFilter').value = 'father';
app.onGroupByAncestorChange();
app.onFilterChange();
shown = sectionCodesShown();
check(shown, { root: true, dad: true, mum: false, uncle: true, aunt: false },
  '"Father\'s side" applies the same way when every individual is shown separately');

// --- Summary counts shrink to match the visible scope (a real exclusion,
// not just a decluttering filter like "Hide exact matches") ---
app._document.getElementById('groupByAncestor').checked = true;
app._document.getElementById('sideFilter').value = 'both';
app.onGroupByAncestorChange();
app.onFilterChange();
const bothCount = app._document.getElementById('report').innerHTML.match(/<div class="num">(\d+)<\/div>/)[1];
app._document.getElementById('sideFilter').value = 'father';
app.onFilterChange();
const fatherCount = app._document.getElementById('report').innerHTML.match(/<div class="num">(\d+)<\/div>/)[1];
check(Number(fatherCount) < Number(bothCount), true,
  '"Father\'s side" reduces the "matched & compared" summary count, not just what\'s displayed');

process.exit(summary('side-filter'));
