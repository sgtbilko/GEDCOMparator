// Tests the five per-category tickboxes on the summary cards (exact,
// similar, diffs/needs-verification, substantial, missing) that replaced the
// old standalone "Hide exact matches", "Hide all matches / show only
// missing people", and "Only show items needing attention" checkboxes.
// Unticking a card's checkbox should hide only that category's rows,
// leaving every other category's rows (and every summary count) untouched —
// the same "hidden, not uncounted" contract the old checkboxes had.
const { loadApp, check, summary } = require('../harness');

// Root has four siblings, one per non-missing category, plus one sibling
// missing entirely from File B:
//  - Clean:  an exact match                                  -> "exact"
//  - Blurry: a location difference within the similarity      -> "similar"
//            threshold (a leniency-only match)
//  - Fuzzy:  an ordinary, non-substantial diff (birth year)   -> "diffs"
//  - Rogue:  a substantially different name                   -> "substantial"
//  - OnlyInA: missing entirely from File B                    -> "missing"
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F2@
0 @I2@ INDI
1 NAME Clean /Person/
1 BIRT
2 DATE 1900
2 PLAC Boston
1 FAMC @F2@
0 @I3@ INDI
1 NAME Fuzzy /Person/
1 BIRT
2 DATE 1900
2 PLAC Boston
1 FAMC @F2@
0 @I4@ INDI
1 NAME Rogue /Person/
1 BIRT
2 DATE 1900
1 FAMC @F2@
0 @I5@ INDI
1 NAME Blurry /Person/
1 BIRT
2 DATE 1900
2 PLAC Springfield, Illinois
1 FAMC @F2@
0 @I6@ INDI
1 NAME OnlyInA /Person/
1 FAMC @F2@
0 @F2@ FAM
1 CHIL @I1@
1 CHIL @I2@
1 CHIL @I3@
1 CHIL @I4@
1 CHIL @I5@
1 CHIL @I6@
`;
const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMC @G2@
0 @P2@ INDI
1 NAME Clean /Person/
1 BIRT
2 DATE 1900
2 PLAC Boston
1 FAMC @G2@
0 @P3@ INDI
1 NAME Fuzzy /Person/
1 BIRT
2 DATE 1905
2 PLAC Boston
1 FAMC @G2@
0 @P4@ INDI
1 NAME Zachary /Person/
1 BIRT
2 DATE 1900
1 FAMC @G2@
0 @P5@ INDI
1 NAME Blurry /Person/
1 BIRT
2 DATE 1900
2 PLAC Springfield, IL
1 FAMC @G2@
0 @G2@ FAM
1 CHIL @P1@
1 CHIL @P2@
1 CHIL @P3@
1 CHIL @P4@
1 CHIL @P5@
`;

const app = loadApp({
  rootA: 'I1', rootB: 'P1', maxGen: '1', includeSiblings: true, ignoreLikelyAlive: false,
  categoryVisibility: { exact: true }
});
app.loadGedcomFiles(gedA, gedB);
app.runCompare();

function shown() {
  const html = app._document.getElementById('report').innerHTML;
  return {
    clean: html.includes('Clean Person'),
    blurry: html.includes('Blurry Person'),
    fuzzy: html.includes('Fuzzy Person'),
    rogue: html.includes('Rogue Person'),
    onlyInA: html.includes('OnlyInA Person')
  };
}

// --- Sanity: with every tickbox checked, every category is visible ---
check(shown(), { clean: true, blurry: true, fuzzy: true, rogue: true, onlyInA: true },
  'with every summary-card tickbox checked, one row of each category is visible');
const baselineSummary = app._document.getElementById('report').innerHTML.match(/<div class="num">(\d+)<\/div>/g);

// --- A fresh app (no override) starts with exact matches hidden, matching
// the old "Hide exact matches" default; every other category starts shown ---
{
  const defaultApp = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', includeSiblings: true, ignoreLikelyAlive: false });
  defaultApp.loadGedcomFiles(gedA, gedB);
  defaultApp.runCompare();
  const html = defaultApp._document.getElementById('report').innerHTML;
  check(html.includes('Clean Person'), false, 'a fresh app starts with exact matches hidden, matching the old default');
  check(html.includes('Fuzzy Person') && html.includes('Rogue Person') && html.includes('OnlyInA Person') && html.includes('Blurry Person'),
    true, 'every other category starts shown by default');
}

// --- Unticking each category hides only that category's rows ---
app.onCategoryToggle('substantial', false);
check(shown(), { clean: true, blurry: true, fuzzy: true, rogue: false, onlyInA: true },
  'unticking "Substantial difference" hides only Rogue');
app.onCategoryToggle('substantial', true);

app.onCategoryToggle('diffs', false);
check(shown(), { clean: true, blurry: true, fuzzy: false, rogue: true, onlyInA: true },
  'unticking "Possible match / needs verification" hides only Fuzzy');
app.onCategoryToggle('diffs', true);

app.onCategoryToggle('similar', false);
check(shown(), { clean: true, blurry: false, fuzzy: true, rogue: true, onlyInA: true },
  'unticking "In both, similar match" hides only Blurry');
app.onCategoryToggle('similar', true);

app.onCategoryToggle('missing', false);
check(shown(), { clean: true, blurry: true, fuzzy: true, rogue: true, onlyInA: false },
  'unticking "Missing from either file" hides only OnlyInA');
app.onCategoryToggle('missing', true);

app.onCategoryToggle('exact', false);
check(shown(), { clean: false, blurry: true, fuzzy: true, rogue: true, onlyInA: true },
  'unticking "Exact match" hides only Clean');
app.onCategoryToggle('exact', true);

// --- Toggling never changes the summary counts — only what's displayed,
// exactly like "Hide exact matches" before it ---
app.onCategoryToggle('exact', false);
app.onCategoryToggle('substantial', false);
const filteredSummary = app._document.getElementById('report').innerHTML.match(/<div class="num">(\d+)<\/div>/g);
check(filteredSummary, baselineSummary, 'summary counts are unchanged regardless of which categories are hidden');
app.onCategoryToggle('exact', true);
app.onCategoryToggle('substantial', true);

// --- Hidden-count legend names the right category ---
app.onCategoryToggle('substantial', false);
check(app._document.getElementById('report').innerHTML.includes('1 substantial difference hidden'), true,
  'the legend reports how many rows of a hidden category were hidden, using that category\'s own name');
app.onCategoryToggle('substantial', true);

// --- Works the same way in flat (ungrouped) display mode ---
app._document.getElementById('groupByAncestor').checked = false;
app.onGroupByAncestorChange();
app.onCategoryToggle('substantial', false);
check(shown().rogue, false, 'category toggles also apply in flat (ungrouped) mode');
app.onCategoryToggle('substantial', true);
app._document.getElementById('groupByAncestor').checked = true;
app.onGroupByAncestorChange();

process.exit(summary('category-toggles'));
