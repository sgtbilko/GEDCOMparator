// End-to-end test confirming the rendered report actually uses the colour
// scheme: missing from EITHER file renders with the same deep-red badge/
// section class ("missing"), distinct from the brighter red reserved
// exclusively for a matched pair flagged as substantially different —
// verified both against a real runCompare()/renderReport() pass and
// directly against the CSS source.
const fs = require('fs');
const path = require('path');
const { loadApp, check, summary } = require('../harness');

// Ancestor tree: Root -> Father(F) -> Grandfather+Grandmother (family F2).
// Grandfather is missing entirely from File B; Grandmother has a
// substantially different given name in File B (Grandmother vs Zachary) —
// a genuine substantial difference. Root -> Mother(M), an exact match with
// nothing missing or different under it.
const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Mum /Person/
1 FAMS @F1@
0 @I4@ INDI
1 NAME Grandfather /Person/
1 FAMS @F2@
0 @I5@ INDI
1 NAME Grandmother /Person/
1 FAMS @F2@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I3@
1 CHIL @I1@
0 @F2@ FAM
1 HUSB @I4@
1 WIFE @I5@
1 CHIL @I2@
`;
const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMC @G1@
0 @P2@ INDI
1 NAME Dad /Person/
1 FAMS @G1@
1 FAMC @G2@
0 @P3@ INDI
1 NAME Mum /Person/
1 FAMS @G1@
0 @P5@ INDI
1 NAME Zachary /Person/
1 FAMS @G2@
0 @G1@ FAM
1 HUSB @P2@
1 WIFE @P3@
1 CHIL @P1@
0 @G2@ FAM
1 WIFE @P5@
1 CHIL @P2@
`;

const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', categoryVisibility: { exact: true } });
app.loadGedcomFiles(gedA, gedB);
app.runCompare();
const html = app._document.getElementById('report').innerHTML;

// --- The Father section (Grandfather missing from B + Grandmother
// substantially different) is red, not "missing" — red outranks missing. ---
check(/class="section-head status-red"/.test(html), true,
  'the section with a substantial difference is red, even though it also has a missing person');

// --- The Mother section (Mum, an exact match, nothing missing/different
// under it) is exact — confirms the two reds aren't applied indiscriminately. ---
{
  const motherIdx = html.indexOf('>Mum Person<');
  check(motherIdx > -1, true, 'sanity: the Mother section is present in the report');
  const headBeforeMother = html.lastIndexOf('class="section-head status-', motherIdx);
  const statusMatch = html.slice(headBeforeMother, headBeforeMother + 40).match(/status-(\w+)/);
  check(statusMatch[1], 'exact', 'the Mother section (an exact match) is exact (the deeper green)');
}

// --- Missing-person badges render (both A- and B-missing appear somewhere
// in a large enough fixture); here Grandfather is missing from File B. ---
check(html.includes('class="badge missB"'), true, 'a "Missing in File B" badge is rendered for Grandfather');

// --- A genuinely exact match renders the "Exact match" badge and the
// deeper-green section-head class, via a real runCompare()/render pass ---
{
  const exactApp = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } });
  const exactGedA = `0 @I1@ INDI\n1 NAME Root /Person/\n1 BIRT\n2 DATE 1900\n2 PLAC Boston\n`;
  const exactGedB = `0 @P1@ INDI\n1 NAME Root /Person/\n1 BIRT\n2 DATE 1900\n2 PLAC Boston\n`;
  exactApp.loadGedcomFiles(exactGedA, exactGedB);
  exactApp.runCompare();
  const exactHtml = exactApp._document.getElementById('report').innerHTML;
  check(exactHtml.includes('class="badge exact">Exact match'), true,
    'a genuinely exact match (identical name, date, and place) renders the "Exact match" badge');
  check(/class="section-head status-exact"/.test(exactHtml), true,
    'its section header uses the deeper-green "exact" class');
}

// --- CSS source: missA and missB share the exact same background/colour
// variables (unified deep red), and that variable is distinct from the
// brighter red used for substantial differences ---
const appDir = path.join(__dirname, '..');
const appFile = fs.readdirSync(appDir).find(f => f.endsWith('.html'));
const source = fs.readFileSync(path.join(appDir, appFile), 'utf8');
const missABadgeRule = source.match(/\.badge\.missA\s*\{([^}]*)\}/)[1];
const missBBadgeRule = source.match(/\.badge\.missB\s*\{([^}]*)\}/)[1];
const sigDiffBadgeRule = source.match(/\.badge\.substantial-diff\s*\{([^}]*)\}/)[1];
check(missABadgeRule.replace(/\s+/g, ' ').trim(), missBBadgeRule.replace(/\s+/g, ' ').trim(),
  '.badge.missA and .badge.missB use identical CSS (same deep red), not distinct colours');
check(missABadgeRule.includes('--missing') && !missABadgeRule.includes('--sig-diff'), true,
  '.badge.missA uses the shared "--missing" (deep red) variable, not the "--sig-diff" (brighter red) one');
check(sigDiffBadgeRule.includes('--sig-diff') && !sigDiffBadgeRule.includes('--missing'), true,
  '.badge.substantial-diff uses the "--sig-diff" (brighter red) variable exclusively');

// --- Section-head status classes: "missing" is its own colour, distinct from "red" ---
const statusMissingRule = source.match(/\.section-head\.status-missing\s*\{([^}]*)\}/)[1];
const statusRedRule = source.match(/\.section-head\.status-red\s*\{([^}]*)\}/)[1];
check(statusMissingRule.includes('--missing'), true, '.section-head.status-missing uses the deep-red "--missing" variable');
check(statusRedRule.includes('--sig-diff'), true, '.section-head.status-red uses the brighter "--sig-diff" variable');
check(statusMissingRule.replace(/\s+/g, ' ').trim() === statusRedRule.replace(/\s+/g, ' ').trim(), false,
  'status-missing and status-red are visually distinct rules, not aliases of each other, despite both being shades of red');

// --- The two greens (exact vs. similar) are genuinely distinct colours,
// both for the section header and the per-row badge ---
const statusExactRule = source.match(/\.section-head\.status-exact\s*\{([^}]*)\}/)[1];
const statusSimilarRule = source.match(/\.section-head\.status-similar\s*\{([^}]*)\}/)[1];
check(statusExactRule.includes('--exact-soft'), true, '.section-head.status-exact uses the deeper "--exact-soft" variable');
check(statusSimilarRule.includes('--accent-soft'), true, '.section-head.status-similar keeps the original lighter "--accent-soft" green');
check(statusExactRule.replace(/\s+/g, ' ').trim() === statusSimilarRule.replace(/\s+/g, ' ').trim(), false,
  'status-exact and status-similar are visually distinct, not the same rule under two names');
const badgeExactRule = source.match(/\.badge\.exact\s*\{([^}]*)\}/)[1];
const badgeBothRule = source.match(/\.badge\.both\s*\{([^}]*)\}/)[1];
check(badgeExactRule.replace(/\s+/g, ' ').trim() === badgeBothRule.replace(/\s+/g, ' ').trim(), false,
  '.badge.exact and .badge.both are visually distinct, not the same rule under two names');

// --- The two reds (missing vs. substantial) actually differ in hex value,
// not just in variable name ---
const missingHex = source.match(/--missing:\s*(#[0-9a-fA-F]+)/)[1];
const sigDiffHex = source.match(/--sig-diff:\s*(#[0-9a-fA-F]+)/)[1];
check(missingHex === sigDiffHex, false, 'the "missing" red and the "substantial difference" red are different hex colours');

process.exit(summary('coloring-scheme'));
