// Tests that "Reviewed" marks survive closing and reopening the page: they
// persist to localStorage keyed by a fingerprint of exactly the two loaded
// files' contents (reviewStorageKey), keyed per-person (not per row id, which
// isn't stable across separate page loads / comparisons), and are reloaded
// automatically the next time the same two files are compared. Two separate
// loadApp() calls sharing the same `storageBacking` object simulate two
// separate page loads in the same browser.
const { loadApp, check, summary } = require('../harness');

const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F1@
0 @I2@ INDI
1 NAME Dad /Person/
1 FAMS @F1@
1 FAMC @F2@
0 @I3@ INDI
1 NAME Mum /Person/
1 FAMS @F1@
0 @I4@ INDI
1 NAME OnlyInA /Person/
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @I2@
1 WIFE @I3@
1 CHIL @I1@
0 @F2@ FAM
1 CHIL @I2@
1 CHIL @I4@
`;
const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMC @G1@
0 @P2@ INDI
1 NAME Dad /Person/
1 FAMS @G1@
1 FAMC @G2@
0 @P3@ INDI
1 NAME Mum /Person/
1 FAMS @G1@
0 @G1@ FAM
1 HUSB @P2@
1 WIFE @P3@
1 CHIL @P1@
0 @G2@ FAM
1 CHIL @P2@
`;

// --- Basic round trip: mark reviewed, "reopen the page", mark still there ---
{
  const storage = {};
  const session1 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, categoryVisibility: { exact: true } }, storage);
  session1.loadGedcomFiles(gedA, gedB);
  session1.runCompare();
  const fatherSection1 = session1.getVar('lastSections').find(s => s.label === 'Father');
  const onlyInARow = fatherSection1.rows.find(r => r.name === 'OnlyInA Person');
  session1.toggleReviewed(session1.personKey(onlyInARow), true);
  check(Object.keys(storage).length, 1, 'marking a row reviewed writes exactly one localStorage key');

  // A brand-new loadApp() call is a brand-new vm context — a fresh "page load"
  // — but it shares the SAME storage object, i.e. the same browser profile.
  const session2 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, categoryVisibility: { exact: true } }, storage);
  session2.loadGedcomFiles(gedA, gedB);
  session2.runCompare();
  const fatherSection2 = session2.getVar('lastSections').find(s => s.label === 'Father');
  const onlyInARow2 = fatherSection2.rows.find(r => r.name === 'OnlyInA Person');
  check(session2.getVar('reviewedIds').has(session2.personKey(onlyInARow2)), true,
    'reopening the page with the same two files restores the reviewed mark');
}

// --- A different pair of files never sees another pair's reviewed marks ---
{
  const storage = {};
  const session1 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } }, storage);
  session1.loadGedcomFiles(gedA, gedB);
  session1.runCompare();
  const root1 = session1.getVar('lastSections').find(s => s.label === 'Root').ancestorHeader;
  session1.toggleReviewed(session1.personKey(root1), true);

  const otherGedA = `0 @X1@ INDI\n1 NAME Someone /Else/\n`;
  const otherGedB = `0 @Y1@ INDI\n1 NAME Someone /Else/\n`;
  const session2 = loadApp({ rootA: 'X1', rootB: 'Y1', maxGen: '1' }, storage);
  session2.loadGedcomFiles(otherGedA, otherGedB);
  session2.runCompare();
  check(session2.getVar('reviewedIds').size, 0, 'a different pair of files starts with no reviewed marks, even sharing the same storage');
}

// --- Reviewed state survives even if row order/ids change between compares
// (e.g. a different maxGen), because it's keyed by person, not row id ---
{
  const storage = {};
  const session1 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } }, storage);
  session1.loadGedcomFiles(gedA, gedB);
  session1.runCompare();
  const root1 = session1.getVar('lastSections').find(s => s.label === 'Root').ancestorHeader;
  session1.toggleReviewed(session1.personKey(root1), true);

  // Same files, but now with a deeper maxGen — row ids are assigned in a
  // different sequence/quantity than session1's.
  const session2 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '2', includeSiblings: true, categoryVisibility: { exact: true } }, storage);
  session2.loadGedcomFiles(gedA, gedB);
  session2.runCompare();
  const root2 = session2.getVar('lastSections').find(s => s.label === 'Root').ancestorHeader;
  check(session2.getVar('reviewedIds').has(session2.personKey(root2)), true,
    'the reviewed mark still applies to Root even though maxGen (and therefore row ids) changed between compares');
}

// --- Un-reviewing persists too (removes the mark, not just adds) ---
{
  const storage = {};
  const session1 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } }, storage);
  session1.loadGedcomFiles(gedA, gedB);
  session1.runCompare();
  const root1 = session1.getVar('lastSections').find(s => s.label === 'Root').ancestorHeader;
  session1.toggleReviewed(session1.personKey(root1), true);
  session1.toggleReviewed(session1.personKey(root1), false);

  const session2 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } }, storage);
  session2.loadGedcomFiles(gedA, gedB);
  session2.runCompare();
  check(session2.getVar('reviewedIds').size, 0, 'un-ticking Reviewed persists the removal, not just the addition');
}

// --- "Clear saved review marks" wipes both in-memory state and storage ---
{
  const storage = {};
  const session1 = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', categoryVisibility: { exact: true } }, storage);
  session1.loadGedcomFiles(gedA, gedB);
  session1.runCompare();
  const root1 = session1.getVar('lastSections').find(s => s.label === 'Root').ancestorHeader;
  session1.toggleReviewed(session1.personKey(root1), true);
  check(Object.keys(storage).length, 1, 'sanity: a mark was saved before clearing');

  session1.clearReviewedForTheseFiles();
  check(session1.getVar('reviewedIds').size, 0, 'clearing empties the in-memory reviewedIds immediately');
  check(Object.keys(storage).length, 0, 'clearing also removes the localStorage entry, not just the in-memory copy');
}

// --- Storage errors are non-fatal ---
{
  const storage = {};
  const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1' }, storage);
  app.loadGedcomFiles(gedA, gedB);
  app.runCompare();
  const throwingKey = app.getVar('reviewStorageKey');
  // Simulate a browser that throws on localStorage access (private mode, etc).
  app._document; // no-op, just keeping the pattern consistent
  let threw = false;
  try {
    app.getVar('localStorage'); // sanity — should exist
  } catch (e) { threw = true; }
  check(threw, false, 'localStorage stub is reachable at all (sanity check)');
  check(typeof throwingKey, 'string', 'reviewStorageKey is set once files are loaded, even without opening the root panel UI');
}

process.exit(summary('reviewed-persistence'));
