// Tests the 5-box summary layout: exact (deep green), similar (light
// green), diffs/needs-verification (amber), substantial (red), and missing
// (purple, merged across both files with a File A/File B sub-label) — one
// card per status colour, in worst-to-best order, replacing the separate
// colour-key legend entirely.
const { loadApp, check, summary } = require('../harness');

const gedA = `0 @I1@ INDI
1 NAME Root /Person/
1 FAMC @F2@
1 FAMS @F1@
0 @I2@ INDI
1 NAME Rogue /Person/
1 BIRT
2 DATE 1900
1 FAMS @F1@
0 @I3@ INDI
1 NAME OnlyInA /Person/
1 FAMC @F2@
0 @F1@ FAM
1 HUSB @I1@
1 WIFE @I2@
0 @F2@ FAM
1 CHIL @I1@
1 CHIL @I3@
`;
const gedB = `0 @P1@ INDI
1 NAME Root /Person/
1 FAMC @G2@
1 FAMS @G1@
0 @P2@ INDI
1 NAME Zachary /Person/
1 BIRT
2 DATE 1900
1 FAMS @G1@
0 @P4@ INDI
1 NAME OnlyInB /Person/
1 FAMC @G2@
0 @G1@ FAM
1 HUSB @P1@
1 WIFE @P2@
0 @G2@ FAM
1 CHIL @P1@
1 CHIL @P4@
`;
// Root: exact match (identical name, no other fields recorded). Spouse:
// Rogue/Zachary — a substantially different name (red). Root's siblings:
// OnlyInA (missing from File B), OnlyInB (missing from File A).

const app = loadApp({ rootA: 'I1', rootB: 'P1', maxGen: '1', includeSiblings: true, hideExactMatches: false, ignoreLikelyAlive: false });
app.loadGedcomFiles(gedA, gedB);
app.runCompare();
const html = app._document.getElementById('report').innerHTML;

// --- Exactly 5 cards, in worst-to-best order ---
const cardClasses = [...html.matchAll(/<div class="card (\w+)">/g)].map(m => m[1]);
check(cardClasses, ['exact', 'similar', 'diffs', 'substantial', 'missing'],
  'the five summary cards appear in order: exact, similar, diffs (amber), substantial (red), missing (purple)');

// --- The separate colour-key legend is gone; the cards ARE the legend now ---
check(html.includes('Possible match / needs verification</span>'), false,
  'the old separate colour-key legend with dot spans no longer renders');
check(/<span class="dot"/.test(html), false, 'no legend dot spans remain anywhere in the report');

// --- Exact card counts the one genuinely exact match (Root) ---
const exactNum = html.match(/<div class="card exact"><div class="num">(\d+)<\/div>/)[1];
check(exactNum, '1', 'the exact card counts the one genuinely exact match (Root)');

// --- The substantial-differences card counts exactly the one red match ---
const substantialNum = html.match(/<div class="card substantial"><div class="num">(\d+)<\/div>/)[1];
check(substantialNum, '1', 'the substantial-differences card counts the one substantially-different match (Rogue/Zachary)');

// --- The missing card is a single merged total with an A/B breakdown beneath it ---
const missingBlock = html.match(/<div class="card missing">([\s\S]*?)<\/div>\s*<\/div>/)[0];
check(missingBlock.includes('<div class="num">2</div>'), true,
  'the missing card shows ONE combined total (1 from A + 1 from B = 2), not two separate cards');
check(missingBlock.includes('class="sublbl"'), true, 'the missing card has a sub-label element for the per-file breakdown');
check(/File A: 1.*File B: 1/.test(missingBlock), true, 'the sub-label breaks the combined total back down by file');

// --- No old-style summary cards remain ---
check(html.includes('class="card missA"') || html.includes('class="card missB"') || html.includes('class="card matches"'),
  false, 'the old separate per-file missing cards and the old "matched & compared" card no longer exist');

process.exit(summary('summary-cards'));
