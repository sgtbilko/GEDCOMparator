// Minimal reconstruction of the project's Node vm-based test harness:
// loads GEDCOMparator.html's inline <script> into a sandboxed context with a
// stubbed `document`, exposing top-level functions on the returned app object
// plus loadGedcomFiles()/getVar() helpers for reading/writing top-level let/const state.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function extractScript(html) {
  const m = html.match(/<script>([\s\S]*?)<\/script>/);
  if (!m) throw new Error('No <script> block found');
  return m[1];
}

function makeStubDocument() {
  const elements = {};
  function el(id) {
    if (!elements[id]) {
      elements[id] = {
        value: '', checked: false, textContent: '', innerHTML: '',
        style: {}, disabled: false,
        classList: { toggle() {}, add() {}, remove() {} },
        addEventListener() {}, scrollIntoView() { this._scrollIntoViewCalls = (this._scrollIntoViewCalls || 0) + 1; }
      };
    }
    return elements[id];
  }
  return {
    _el: el,
    getElementById: id => el(id),
    createElement: () => ({ style: {} })
  };
}

function loadApp(initial = {}, storageBacking = {}) {
  const scriptSrc = extractScript(fs.readFileSync(path.join(__dirname, 'GEDCOMparator.html'), 'utf8'));
  const document = makeStubDocument();

  // categoryVisibility isn't a checkbox in the DOM (its five tickboxes live
  // inside the report's own re-rendered innerHTML — see the app's own
  // comment above `let categoryVisibility`), so it can't be seeded the same
  // way as the other checked/value defaults below. Pull it out of `initial`
  // and apply it directly to the sandbox's top-level variable once the
  // script has loaded instead.
  const { categoryVisibility: categoryVisibilityOverride, ...checkboxInitial } = initial;

  // Seed defaults matching the real HTML's checked/value attributes exactly,
  // so tests reflect actual default behavior; overrides layer on top.
  const defaults = {
    maxGen: '6', descendantGen: '0',
    includeAncestorSpouses: true, includeSiblings: false, includeSibSpouses: false,
    hideAllSubDetails: true, groupByAncestor: true, sideFilter: 'both', hideReviewedItems: true,
    ignoreLikelyAlive: true, hideNoBirthDate: false, ignoreSimilarLocations: true,
    aliveYears: '80', locationThreshold: '50'
  };
  const merged = Object.assign({}, defaults, checkboxInitial);
  for (const [id, val] of Object.entries(merged)) {
    const e = document._el(id);
    if (typeof val === 'boolean') e.checked = val; else e.value = val;
  }

  const sandbox = { document, console, URL, Date };
  // A stub localStorage backed by a plain object the caller can pass in and
  // reuse across two separate loadApp() calls — that's how a test simulates
  // "close and reopen the page" (two fresh vm contexts / script loads
  // sharing what would be the same browser's localStorage) rather than just
  // reusing the same in-memory context.
  sandbox.localStorage = {
    getItem: k => (Object.prototype.hasOwnProperty.call(storageBacking, k) ? storageBacking[k] : null),
    setItem: (k, v) => { storageBacking[k] = String(v); },
    removeItem: k => { delete storageBacking[k]; }
  };
  vm.createContext(sandbox);
  vm.runInContext(scriptSrc, sandbox);

  // Apply any categoryVisibility overrides (e.g. { exact: true } to reveal
  // exact matches, which default to hidden) onto the live sandbox object,
  // the same way a test mutates reviewedIds/collapsedSections via getVar().
  if (categoryVisibilityOverride) {
    Object.assign(vm.runInContext('categoryVisibility', sandbox), categoryVisibilityOverride);
  }


  // Top-level `let`/`const` bindings (dataA, dataB, lastSections, ...) are NOT
  // exposed as own properties of the sandbox object — that's normal vm/lexical
  // scoping, not a bug — but they stay live across separate runInContext calls
  // on the same context. So reading/writing them has to happen by running a
  // further snippet *inside* the context, not by touching the sandbox object.
  const app = { getVar: varName => vm.runInContext(varName, sandbox) };
  for (const key of Object.keys(sandbox)) {
    if (typeof sandbox[key] === 'function') app[key] = sandbox[key];
  }
  app.loadGedcomFiles = (gedA, gedB) => {
    sandbox.__gedA = gedA;
    sandbox.__gedB = gedB;
    // Sets reviewStorageKey the same way maybeShowRootPanel() does (needed
    // for any test touching Reviewed-mark persistence), without calling
    // maybeShowRootPanel() itself — that also runs tryAutoMatchRoot(),
    // which would clobber a rootA/rootB value a test explicitly passed to
    // loadApp() if the fixture happens to contain any other same-named pair.
    vm.runInContext(
      'dataA = parseGedcom(__gedA); dataB = parseGedcom(__gedB); rawTextA = __gedA; rawTextB = __gedB; ' +
      'reviewStorageKey = "gedcomparator-reviewed:" + hashString(rawTextA) + ":" + hashString(rawTextB);',
      sandbox
    );
  };
  app._document = document;
  return app;
}

let passCount = 0, failCount = 0;
function check(actual, expected, desc) {
  const pass = JSON.stringify(actual) === JSON.stringify(expected);
  if (pass) passCount++; else failCount++;
  console.log(`${pass ? 'PASS' : 'FAIL'} | ${desc}${pass ? '' : ` (expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)})`}`);
}
function summary(name) {
  console.log(`\n${name}: ${passCount} passed, ${failCount} failed`);
  return failCount > 0 ? 1 : 0;
}

module.exports = { loadApp, check, summary };
