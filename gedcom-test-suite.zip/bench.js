// Timing for the two hot paths. Usage: node bench.js [depth=10]
// depth 10 ~ 1,000 ancestors and roughly 4,000 people per file.
const { performance } = require('perf_hooks');
const { loadApp } = require('./harness');
const { buildTree, toGedcom, MUTATION } = require('./gen-fixture');
const depth = parseInt(process.argv[2] || '10', 10);
const tree = buildTree(depth, 7);
const gedA = toGedcom(tree, null, 1), gedB = toGedcom(tree, MUTATION, 2);
const app = loadApp({ rootA: 'I1', rootB: 'I1', maxGen: 'all', includeSiblings: true, includeSibSpouses: true,
  includeAncestorSpouses: true, descendantGen: '2', generationLimit: 'all', groupByAncestor: true, hideAllSubDetails: true,
  categoryVisibility: { exact: true, similar: true } });
const t = (label, fn, reps = 1) => { const s = performance.now(); for (let i = 0; i < reps; i++) fn(); console.log(label.padEnd(44) + ((performance.now() - s) / reps).toFixed(1) + ' ms'); };
console.log(`depth ${depth}: ${tree.n} people, ${(gedA.length / 1024).toFixed(0)} KB per file`);
t('parseGedcom x2 + load', () => app.loadGedcomFiles(gedA, gedB));
t('runCompare (compare + first render)', () => app.runCompare());
const doc = app._document;
t('renderReport (no setting change)', () => app.renderReport(), 5);
t('renderReport after nameTolerance slider move', () => { doc._el('nameTolerance').value = String(5 + Math.floor(Math.random() * 20)); app.renderReport(); }, 5);
console.log('report HTML size: ' + (doc._el('report').innerHTML.length / 1024).toFixed(0) + ' KB');
