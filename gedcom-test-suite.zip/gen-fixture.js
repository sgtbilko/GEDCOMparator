// Deterministic synthetic GEDCOM pair generator, shared by snapshot.js and bench.js.
// buildTree(depth, seed) -> a family tree; toGedcom(tree, mutation|null, seed) -> GEDCOM text.
// File A = toGedcom(tree, null); File B = toGedcom(tree, { ...rates }) (a perturbed copy).
function rng(seed) { let s = seed >>> 0; return () => (s = (Math.imul(s, 1664525) + 1013904223) >>> 0) / 4294967296; }

function buildTree(depth, seed) {
  const rand = rng(seed);
  const pick = arr => arr[Math.floor(rand() * arr.length)];
  const people = {}, fams = {}; let n = 0, f = 0;
  const surnames = ['Smith', 'Jones', 'Taylor', 'Brown', 'Wilson', 'Davies'];
  const places = ['Leeds, Yorkshire, England', 'Paris, France', 'Springfield, Illinois, USA', 'Torgau, Germany', 'Dublin, Ireland'];
  function person(sex, year, surname) {
    const id = 'I' + (++n);
    const given = pick(sex === 'M' ? ['John', 'Henry', 'George', 'Albert'] : ['Mary', 'Ann', 'Alice', 'Edith']) + (rand() < 0.3 ? ' James' : '');
    people[id] = { id, sex, given, surname, year, deathYear: year + 30 + Math.floor(rand() * 50), place: pick(places),
      www: rand() < 0.2 ? 'https://www.wikitree.com/wiki/P-' + n : null, famc: null, fams: [] };
    return id;
  }
  function family(h, w, year) {
    const id = 'F' + (++f);
    fams[id] = { id, husb: h, wife: w, chil: [], year, place: pick(places) };
    if (h) people[h].fams.push(id);
    if (w) people[w].fams.push(id);
    return id;
  }
  function child(fid, c) { fams[fid].chil.push(c); people[c].famc = fid; }

  const root = person('M', 1960, 'Smith');
  function addParents(p, gen) {
    if (gen >= depth) return;
    const y = people[p].year;
    const fa = person('M', y - 28, people[p].sex === 'M' ? people[p].surname : pick(surnames));
    const mo = person('F', y - 26, pick(surnames));
    const fid = family(fa, mo, y - 2);
    child(fid, p);
    const k = Math.floor(rand() * 3);
    for (let i = 0; i < k; i++) child(fid, person(rand() < 0.5 ? 'M' : 'F', y + (i + 1) * 2 - 4, people[fa].surname));
    if (rand() < 0.4) { // a second marriage: half-sibling, their spouse and child
      const w2 = person('F', people[fa].year + 3, pick(surnames));
      const f2 = family(fa, w2, y + 3);
      const hs = person('M', y + 5, people[fa].surname);
      child(f2, hs);
      const sp = person('F', y + 6, pick(surnames));
      const fh = family(hs, sp, y + 28);
      child(fh, person(rand() < 0.5 ? 'M' : 'F', y + 30, people[hs].surname));
    }
    addParents(fa, gen + 1); addParents(mo, gen + 1);
  }
  addParents(root, 0);
  // the root's own spouse, child and grandchild
  const rs = person('F', 1962, pick(surnames));
  const rf = family(root, rs, 1985);
  const rc = person('F', 1988, 'Smith'); child(rf, rc);
  const rcs = person('M', 1987, pick(surnames));
  const rcf = family(rcs, rc, 2012);
  child(rcf, person('M', 2014, people[rcs].surname));
  return { people, fams, root, n, f };
}

function toGedcom(tree, mut, seed) {
  const rand = rng(seed || 1);
  const dropped = new Set();
  if (mut) for (const id of Object.keys(tree.people)) if (id !== tree.root && rand() < mut.drop) dropped.add(id);
  const out = ['0 HEAD', '1 CHAR UTF-8'];
  const misspell = s => s.length > 3 ? s.slice(0, 2) + 'x' + s.slice(3) : s;
  for (const p of Object.values(tree.people)) {
    if (dropped.has(p.id)) continue;
    let given = p.given, surname = p.surname, year = p.year, place = p.place, hasBirth = true, dateText = String(year);
    if (mut) {
      if (rand() < mut.misspell) given = misspell(given);
      if (rand() < mut.surnameChange) surname = misspell(surname);
      if (rand() < mut.yearShift) year += (rand() < 0.5 ? -1 : 1) * (1 + Math.floor(rand() * 15));
      if (rand() < mut.placeChange) place = 'Elsewhere, Nowhere';
      if (rand() < mut.noBirth) hasBirth = false;
      dateText = rand() < mut.aboutDate ? 'ABT ' + year : (rand() < 0.3 ? `12 Nov ${year}` : String(year));
    } else dateText = rand() < 0.3 ? `12 Nov ${year}` : String(year);
    out.push(`0 @${p.id}@ INDI`, `1 NAME ${given} /${surname}/`, `1 SEX ${p.sex}`);
    if (hasBirth) out.push('1 BIRT', `2 DATE ${dateText}`, `2 PLAC ${place}`);
    if (p.deathYear < 2020) out.push('1 DEAT', `2 DATE ${p.deathYear}`);
    if (p.famc) out.push(`1 FAMC @${p.famc}@`);
    for (const fs of p.fams) out.push(`1 FAMS @${fs}@`);
    if (p.www) out.push(`1 WWW ${p.www}`);
  }
  for (const fm of Object.values(tree.fams)) {
    out.push(`0 @${fm.id}@ FAM`);
    if (fm.husb && !dropped.has(fm.husb)) out.push(`1 HUSB @${fm.husb}@`);
    if (fm.wife && !dropped.has(fm.wife)) out.push(`1 WIFE @${fm.wife}@`);
    for (const c of fm.chil) if (!dropped.has(c)) out.push(`1 CHIL @${c}@`);
    out.push('1 MARR', `2 DATE ${fm.year}`, `2 PLAC ${fm.place}`);
  }
  out.push('0 TRLR');
  return out.join('\n') + '\n';
}

const MUTATION = { drop: 0.08, misspell: 0.08, surnameChange: 0.05, yearShift: 0.12, placeChange: 0.12, noBirth: 0.08, aboutDate: 0.1 };
module.exports = { buildTree, toGedcom, MUTATION };
